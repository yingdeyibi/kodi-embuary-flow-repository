"""Bundled, guided native installation; never writes installed addon files."""
import hashlib
import json
import os
from pathlib import Path
import re

from archives import addon_metadata


TITLE = 'Flow 安装助手'
LABELS = {
    'missing': '未安装', 'disabled': '已安装但未启用',
    'different_version': '版本不同，保留现有版本，需人工核对',
    'files_match': '指定文件核对通过', 'files_differ': '指定文件不同，需核对后安装',
    'unreadable': '文件无法读取，需检查',
    'patch_needed': '版本匹配，缺少已核验补丁',
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def package_bytes(root, item):
    """Validate the complete package before exporting any installation file."""
    filename = item['package']
    if filename != os.path.basename(filename) or '\\' in filename or ':' in filename:
        raise ValueError('invalid_package_path')
    data = (Path(root) / 'resources/packages' / filename).read_bytes()
    if len(data) != item['bytes'] or digest(data) != item['sha256']:
        raise ValueError('package_hash_mismatch')
    addon_metadata(data, item['id'], item['version'])
    return data


def inspect(item, installed, read_file):
    """Exact versions only; never interpret an unfamiliar version as safe to replace."""
    if installed is None:
        return 'missing'
    if installed['version'] != item['version']:
        return 'different_version'
    if not installed['enabled']:
        return 'disabled'
    try:
        missing_patch = False
        for relative, expected in item['checks'].items():
            actual = digest(read_file(relative))
            if actual != expected:
                if actual != item.get('original_checks', {}).get(relative):
                    return 'files_differ'
                missing_patch = True
    except OSError:
        return 'unreadable'
    return 'patch_needed' if missing_patch else 'files_match'


def installation_plan(items, states):
    """Skip verified packages and stop for unfamiliar installed content."""
    return ([item for item, state in zip(items, states) if state in ('missing', 'patch_needed')],
            [item for item, state in zip(items, states)
             if state not in ('missing', 'patch_needed', 'files_match')])


def export_packages(root, items, directory):
    """Only write verified ZIPs to the chosen folder, never extract into Kodi."""
    packages = [(item['package'], package_bytes(root, item)) for item in items]
    target = Path(directory) / 'Flow-install-0.4.1'
    # Check all collisions before writing; unrelated files are left alone.
    for filename, data in packages:
        path = target / filename
        if path.exists() and path.read_bytes() != data:
            raise ValueError('export_file_conflict')
    target.mkdir(parents=True, exist_ok=True)
    for filename, data in packages:
        path = target / filename
        if not path.exists():
            path.write_bytes(data)
        if digest(path.read_bytes()) != digest(data):
            raise OSError('export_verification_failed')
    return target


def installed_addon(xbmc, addon_id):
    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddonDetails',
        'params': {'addonid': addon_id, 'properties': ['version', 'enabled']}})))
    if 'error' in response:
        if response['error'].get('code') != -32602:
            raise ValueError('addon_query_failed')
        return None
    return response['result']['addon']


def external_dependencies(items):
    bundled = {item['id'] for item in items}
    return sorted({dependency['id'] for item in items for dependency in item.get('requires', [])
                   if not dependency['optional'] and dependency['id'] not in bundled
                   and not dependency['id'].startswith('xbmc.')})


def run():
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs

    dialog = xbmcgui.Dialog()
    addon = xbmcaddon.Addon()
    root = Path(xbmcvfs.translatePath(addon.getAddonInfo('path')))
    try:
        items = json.loads((root / 'resources/install-manifest.json').read_text('utf-8'))['addons']
        while True:
            choice = dialog.select(TITLE, ['查看安装状态', '准备安装包并打开原生安装',
                                          '安装后的设置提示', '安装缺少的仓库依赖'])
            if choice < 0:
                return
            if choice == 2:
                dialog.ok(TITLE, '安装顺序：配套补丁 → Flow Helper → Flow 皮肤。\n'
                          '在界面设置中选择 Flow；按需配置 Jellyfin、天气等。\n'
                          'Flow Helper → 插件更新保护：逐项关闭四个带补丁插件的自动更新。')
                continue
            if xbmc.Player().isPlaying() or xbmc.getCondVisibility('Library.IsScanningVideo'):
                dialog.ok(TITLE, '请在播放和视频扫描结束后使用安装检查或引导。')
                continue
            dependencies = [(addon_id, installed_addon(xbmc, addon_id))
                            for addon_id in external_dependencies(items)]
            if choice == 3:
                missing = [addon_id for addon_id, state in dependencies if state is None]
                if not missing:
                    dialog.ok(TITLE, '没有缺少的仓库依赖。版本及启用要求由 Kodi 安装时核对。')
                    continue
                selected = dialog.select('选择缺少的依赖（由 Kodi 仓库安装）', missing)
                if selected >= 0:
                    addon_id = missing[selected]
                    if not re.fullmatch(r'[a-zA-Z0-9._-]+', addon_id):
                        raise ValueError('invalid_dependency_id')
                    xbmc.executebuiltin('InstallAddon(%s)' % addon_id, True)
                continue
            states = []
            for item in items:
                installed = installed_addon(xbmc, item['id'])
                folder = None
                if installed and installed['version'] == item['version'] and installed['enabled']:
                    folder = Path(xbmcvfs.translatePath(
                        xbmcaddon.Addon(item['id']).getAddonInfo('path')))
                state = inspect(item, installed, lambda name: (folder / name).read_bytes())
                states.append(state)
            text = '\n'.join('%s %s：%s' % (item['name'], item['version'], LABELS[state])
                             for item, state in zip(items, states))
            if choice == 0:
                dependency_text = '\n'.join(addon_id + '：' + (
                    '未安装' if state is None else state['version'] + ('（未启用）' if not state['enabled'] else ''))
                    for addon_id, state in dependencies)
                dialog.textviewer(TITLE, text + '\n\n其他依赖：\n' + dependency_text +
                                  '\n\n版本要求由 Kodi 安装时核对。未检查账号、媒体库或配置。')
                continue
            pending, blocked = installation_plan(items, states)
            if blocked:
                dialog.ok(TITLE, '请先核对以下插件的版本、启用状态或自定义修改：\n' +
                          '\n'.join(item['name'] for item in blocked))
                continue
            if not pending:
                dialog.ok(TITLE, '所有指定文件已匹配，无需重复安装。请继续检查安装后的设置提示。')
                continue
            selected = dialog.select('选择要准备的安装包', ['全部安装包'] + [
                item['name'] for item in pending])
            if selected < 0:
                continue
            chosen = pending if selected == 0 else [pending[selected - 1]]
            if not dialog.yesno(TITLE, '将安装包保存到你选择的目录，再打开 Kodi 原生 ZIP 安装窗口。\n'
                                '版本不同的插件请先核对，避免降级或覆盖自定义修改。继续？'):
                continue
            directory = dialog.browseSingle(3, '选择本地安装包保存目录', 'files')
            if not directory:
                continue
            directory = xbmcvfs.translatePath(directory)
            if '://' in directory:
                dialog.ok(TITLE, '请选择本机可写目录。')
                continue
            target = export_packages(root, chosen, directory)
            dialog.ok(TITLE, '安装包已核验并保存到：\n%s\n'
                      '请在接下来的原生窗口中进入该目录，选择对应 ZIP。\n'
                      '安装后重新打开本助手检查结果。' % target)
            xbmc.executebuiltin('InstallFromZip')
            return  # Opening a picker is not an installation result.
    except (OSError, ValueError, KeyError, TypeError) as error:
        xbmc.log('Flow installer: ' + type(error).__name__, xbmc.LOGERROR)
        dialog.ok(TITLE, '检查或准备安装包失败，请查看 Kodi 日志并核对安装包完整性。')
