"""Shared validation for addon ZIPs; callers establish artifact trust separately."""
import io
import xml.etree.ElementTree as ET
import zipfile


def addon_metadata(data, addon_id, expected_version):
    """Reject unsafe entries and corruption before returning validated addon XML."""
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        seen = set()
        for item in archive.infolist():
            # ZipInfo normalizes backslashes on Windows; inspect the original
            # name so a malformed ZIP receives the same verdict on both OSes.
            name = item.orig_filename
            parts = (name[:-1] if name.endswith('/') else name).split('/')
            if (name.startswith('/') or '\\' in name or ':' in name or
                    '\0' in name or
                    any(part in ('', '.', '..') for part in parts)):
                raise ValueError('Unsafe archive path')
            if parts[0] != addon_id:
                raise ValueError('Unexpected archive root')
            key = name.rstrip('/').casefold()
            if key in seen:
                raise ValueError('Duplicate archive entry')
            seen.add(key)
            if (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Archive symlink rejected')
        if archive.testzip():
            raise ValueError('Archive CRC failure')
        metadata = ET.fromstring(archive.read(addon_id + '/addon.xml'))
    if (metadata.tag != 'addon' or metadata.get('id') != addon_id or
            metadata.get('version') != expected_version):
        raise ValueError('ZIP addon metadata mismatch')
    return metadata
