"""One user-requested retry of the current native picture; no cache eviction."""
import json


def reopen_picture(xbmc, dialog):
    def rpc(method, params=None):
        value = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}})))
        if 'error' in value:
            raise ValueError('picture_rpc_failed')
        return value['result']

    try:
        players = rpc('Player.GetActivePlayers')
        if len(players) != 1 or players[0].get('type') != 'picture':
            return False
        player = players[0]['playerid']
        params = {'playerid': player, 'properties': ['file']}
        path = rpc('Player.GetItem', params)['item'].get('file')
        if not isinstance(path, str) or not path:
            return False
        # The user may have changed picture or started another kind of media.
        if (rpc('Player.GetActivePlayers') != players or
                rpc('Player.GetItem', params)['item'].get('file') != path):
            return False
        xbmc.executebuiltin('Dialog.Close(pictureinfo)')
        rpc('Player.Open', {'item': {'file': path}})
        return True  # Request accepted; this does not prove the image loaded.
    except (ValueError, KeyError, TypeError, RuntimeError):
        dialog.notification('Flow 图片', '无法重新打开图片，请返回图片列表后重试。')
        return False
