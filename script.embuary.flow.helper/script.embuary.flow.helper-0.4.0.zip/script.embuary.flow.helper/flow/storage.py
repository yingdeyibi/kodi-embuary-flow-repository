"""Small atomic local state files; caller owns the configuration directory."""
import hashlib
import json
import os
from pathlib import Path
import tempfile


def fingerprint(data):
    return None if data is None else hashlib.sha256(data).hexdigest()


def read_optional(path):
    try:
        return Path(path).read_bytes()
    except FileNotFoundError:
        return None


def atomic_write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
            name = stream.name
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if name and Path(name).exists():
            Path(name).unlink()


def write_json(path, value):
    atomic_write(path, json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode('utf-8'))


def child_path(root, relative):
    root = Path(root).resolve()
    relative = Path(relative)
    if relative.is_absolute() or '..' in relative.parts or ':' in str(relative) or '\\' in str(relative):
        raise ValueError('Unsafe relative path')
    result = (root / relative).resolve()
    if root not in result.parents:
        raise ValueError('Path outside configured root')
    return result
