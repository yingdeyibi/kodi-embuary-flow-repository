"""Bounded asynchronous rating core. All public methods run on the UI dispatcher.

fetch(identity, item_id) runs in a worker, must enforce network timeout, and
returns normalized Rating records. It must only read the configured Jellyfin
cache API. No transport or actual plugin JSON schema is implied here.
"""
from collections import OrderedDict, deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
import math
import time
import threading

RATING_TTL = 3600
EMPTY_TTL = 60


class RequestBusy(RuntimeError):
    pass


class RequestPool:
    """Service-wide bound, including retired engines' running requests."""
    def __init__(self):
        self.executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix='flow-ratings')
        self.lock = threading.Lock()
        self.active = 0
        self.pending = {}

    def submit_keyed(self, key, fn, *args):
        """Coalesce identical reads across focused and visible-row engines.

        Submission is owned by the service thread; completion stays in workers.
        """
        with self.lock:
            self.pending = {k: f for k, f in self.pending.items() if not f.done()}
            existing = self.pending.get(key)
        if existing is not None:
            return existing
        future = self.submit(fn, *args)
        with self.lock:
            self.pending[key] = future
        return future

    def submit(self, fn, *args):
        with self.lock:
            if self.active >= 2:
                raise RequestBusy()
            self.active += 1
        try:
            future = self.executor.submit(fn, *args)
        except Exception:
            self._released(None)
            raise
        future.add_done_callback(self._released)
        return future

    def _released(self, future):
        with self.lock:
            self.active -= 1

    def shutdown(self, wait=False):
        self.executor.shutdown(wait=wait)


@dataclass(frozen=True)
class Identity:
    profile: str
    server: str  # stable non-secret server identity, never token or URL
    user: str
    library_generation: str

    def __post_init__(self):
        if not all(isinstance(x, str) and x for x in (
                self.profile, self.server, self.user, self.library_generation)):
            raise ValueError('Complete rating identity required')


@dataclass(frozen=True)
class Rating:
    source: str
    value: float
    scale: float
    votes: int = None


REJECTION_CODES = frozenset(('invalid_record', 'unknown_source', 'duplicate_source',
                             'empty_value', 'invalid_value', 'inconsistent_scale'))


@dataclass(frozen=True)
class RatingResult:
    ratings: tuple
    rejected: tuple = ()
    cached_at: str = None
    expires_at: float = None  # monotonic deadline of an existing disk record
    error: str = None

    def __iter__(self):
        return iter(self.ratings)


# Internal normalized IDs; the versioned API adapter maps actual provider names.
SOURCES = OrderedDict([
    ('imdb', ('IMDb', 10)), ('tmdb', ('TMDb', 10)),
    ('rt_critics', ('Rotten Tomatoes Critics', 100)),
    ('rt_audience', ('Rotten Tomatoes Audience', 100)),
    ('metacritic', ('Metacritic', 100)), ('trakt', ('Trakt', 100)),
    ('letterboxd', ('Letterboxd', 5)),
])


def slots(ratings, order=None, hidden=(), limit=8):
    if type(limit) is not int or not 1 <= limit <= 8:
        raise ValueError('Slot limit must be 1–8')
    order = tuple(SOURCES) if order is None else tuple(order)
    hidden = set(hidden)
    if len(set(order)) != len(order) or (set(order) | hidden) - set(SOURCES):
        raise ValueError('Unknown or duplicate configured source')
    ordered = list(order) + [key for key in SOURCES if key not in order]
    valid, rejected = {}, []
    for rating in ratings:
        if not isinstance(rating, Rating):
            rejected.append('invalid_record')
            continue
        if not isinstance(rating.source, str) or rating.source not in SOURCES:
            rejected.append('unknown_source')
            continue
        label, scale = SOURCES[rating.source]
        if (type(rating.value) not in (float, int) or not 0 <= rating.value <= scale
                or not math.isfinite(rating.value) or type(rating.scale) not in (float, int)
                or rating.scale != scale):
            rejected.append('invalid_value')
            continue
        if rating.source in valid:
            rejected.append('duplicate_source')
            continue
        votes = rating.votes if type(rating.votes) is int and rating.votes >= 0 else None
        valid[rating.source] = {'source': rating.source, 'label': label,
                                'value': f'{rating.value:g}/{scale}', 'votes': votes}
    return [valid[key] for key in ordered if key in valid and key not in hidden][:limit], rejected


class RatingsError(Exception):
    ALLOWED = {'connection_failed', 'auth_failed', 'mapping_missing', 'endpoint_unavailable',
               'no_cache', 'invalid_data', 'not_configured', 'timeout'}

    def __init__(self, code):
        self.code = code if code in self.ALLOWED else 'invalid_data'
        super().__init__(self.code)


class Ratings:
    def __init__(self, fetch, clock=time.monotonic, executor=None, debounce=0.4,
                 ttl=RATING_TTL, empty_ttl=EMPTY_TTL, capacity=256, result_timeout=3.0,
                 persistent=None, cache_namespace=None):
        if (any(type(value) not in (int, float) or not math.isfinite(value) or value <= 0
                for value in (ttl, empty_ttl)) or not 0.3 <= debounce <= 0.5 or
                type(capacity) is not int or capacity < 1 or not 1.5 <= result_timeout <= 3):
            raise ValueError('Invalid rating cache policy')
        self.fetch, self.clock = fetch, clock
        self.persistent, self.cache_namespace = persistent, cache_namespace
        self.executor = executor or ThreadPoolExecutor(max_workers=2, thread_name_prefix='flow-ratings')
        self.owns_executor = executor is None
        self.debounce, self.ttl, self.empty_ttl, self.capacity = debounce, ttl, empty_ttl, capacity
        self.identity = None
        self.generation = 0
        self.request_id = 0
        self.focus_item = None
        self.revision = 0
        self.ready_at = 0
        self.result_timeout = result_timeout
        self.deadline = 0
        self.jobs = {}  # bounded to two, including obsolete in-flight work
        self.cache = OrderedDict()
        self.cache_generation = [0]  # shared, bounded refresh generation
        self.state, self.values = 'idle', ()
        self.error = None
        self.rejected = ()
        self.closed = False
        self.metrics = dict(memory_hit=0, api_read=0, disk_hit=0)
        self.metric_lock = threading.Lock()
        self.latencies = {name: deque(maxlen=256) for name in
                          ('memory_hit', 'disk_hit', 'api_read', 'result_ready', 'published')}
        self.focus_started = None
        self.publication_recorded = False

    def _sample(self, name, started):
        elapsed = max(0.0, self.clock() - started) * 1000
        with self.metric_lock:
            self.latencies[name].append(elapsed)

    def mark_published(self):
        # Called only after runtime identity checks and property publication.
        if (not self.publication_recorded and self.focus_started is not None
                and self.state in ('ready', 'empty')):
            self._sample('published', self.focus_started)
            self.publication_recorded = True

    def _fetch(self, identity, item, revision):
        started = self.clock()
        if self.persistent and revision == 0:
            cached = self.persistent.read(self.cache_namespace, item)
            if cached:
                self.metrics['disk_hit'] += 1
                self._sample('disk_hit', started)
                return RatingResult(cached.result.ratings, cached.result.rejected,
                                    expires_at=self.clock() + cached.remaining, error=cached.error)
        self.metrics['api_read'] += 1
        started = self.clock()
        try:
            return self.fetch(identity, item)
        finally:
            self._sample('api_read', started)

    def switch_identity(self, identity):
        if identity != self.identity:
            self.invalidate()
            self.identity = identity

    def invalidate(self):
        self.generation += 1
        self.cache.clear()
        self.cancel()

    def cancel(self):
        self.request_id += 1
        self.focus_item = None
        self.focus_started = None
        self.state, self.values, self.error = 'idle', (), None
        self.rejected = ()

    def focus(self, item_id):
        if self.closed:
            raise RuntimeError('Ratings service closed')
        if not isinstance(item_id, str) or not item_id:
            raise ValueError('Mapped item identity required')
        if self.identity is None:
            raise ValueError('Set rating identity before focus')
        if self.focus_item == item_id:
            return self.request_id
        self.request_id += 1
        self.focus_item, self.revision = item_id, 0
        self.focus_started = self.clock()
        self.publication_recorded = False
        self.ready_at = self.clock() + self.debounce
        self.deadline = self.ready_at + self.result_timeout
        self.state, self.values, self.error = 'loading', (), None
        self.rejected = ()
        return self.request_id

    def refresh(self):
        if self.focus_item is None or self.closed:
            return False
        # A pending manual refresh already targets the newest read.
        if self.state == 'loading' and self.revision > 0:
            return False
        self.request_id += 1
        self.revision += 1
        self.cache_generation[0] += 1
        self.focus_started = self.clock()
        self.publication_recorded = False
        self.cache.pop((self.identity, self.focus_item), None)
        if self.persistent:
            self.persistent.forget(self.cache_namespace, self.focus_item)
        self.ready_at = self.clock()
        self.deadline = self.ready_at + self.result_timeout
        self.state, self.values, self.error = 'loading', (), None
        self.rejected = ()
        return True

    def _key(self):
        return (self.generation, self.identity, self.focus_item, self.request_id, self.revision, self.cache_generation[0])

    def _finish(self, values, error=None, rejected=()):
        self.values = values
        self.error = error
        self.rejected = rejected
        self.state = 'error' if error and error != 'no_cache' else ('ready' if values else 'empty')
        if self.focus_started is not None and self.state in ('ready', 'empty'):
            self._sample('result_ready', self.focus_started)

    def pump(self):
        """Nonblocking; apply results on the caller/UI thread, never in a worker."""
        if self.closed:
            return
        if self.focus_item is not None and self.state in ('ready', 'empty'):
            cached = self.cache.get((self.identity, self.focus_item))
            if cached is None or cached[0] <= self.clock():
                # A stationary focus must not keep expired ratings indefinitely.
                # Clear first and reread; a failed read never restores stale values.
                self.request_id += 1
                self.revision = 0
                self.focus_started = self.clock()
                self.publication_recorded = False
                self.ready_at = self.clock()
                self.deadline = self.ready_at + self.result_timeout
                self.state, self.values, self.error = 'loading', (), None
                self.rejected = ()
        if self.state == 'loading' and self.clock() >= self.deadline:
            # Expire presentation even if a transport is still draining its socket.
            self.request_id += 1
            self._finish((), 'timeout')
        for key, future in list(self.jobs.items()):
            if not future.done():
                continue
            del self.jobs[key]
            if key != self._key():
                continue  # no stale UI writes OR stale cache repopulation
            try:
                fetched = future.result()
                rejected = tuple(code for code in fetched.rejected if code in REJECTION_CODES) if isinstance(fetched, RatingResult) else ()
                result = tuple(fetched)
                if not all(isinstance(value, Rating) for value in result):
                    raise RatingsError('invalid_data')
                ttl = self.ttl if result else self.empty_ttl
                error = fetched.error if isinstance(fetched, RatingResult) else None
                if isinstance(fetched, RatingResult) and fetched.expires_at is not None:
                    ttl = fetched.expires_at - self.clock()
                    if ttl <= 0:
                        self.ready_at = self.clock()
                        self.revision += 1
                        continue
                elif self.persistent:
                    self.persistent.write(self.cache_namespace, self.focus_item,
                                          RatingResult(result, rejected), ttl,
                                          getattr(fetched, 'cached_at', None), authenticated=True)
                self.cache[(self.identity, self.focus_item)] = (
                    self.clock() + ttl, result, error, rejected)
                self.cache.move_to_end((self.identity, self.focus_item))
                while len(self.cache) > self.capacity:
                    self.cache.popitem(last=False)
                self._finish(result, error, rejected=rejected)
            except Exception as exc:
                code = exc.code if isinstance(exc, RatingsError) else 'connection_failed'
                if code == 'auth_failed':
                    self.cache.clear()
                    if self.persistent:
                        self.persistent.revoke(self.cache_namespace)
                elif code == 'no_cache':
                    if self.persistent:
                        self.persistent.write(self.cache_namespace, self.focus_item,
                                              RatingResult(()), self.empty_ttl, error=code, authenticated=True)
                    self.cache[(self.identity, self.focus_item)] = (
                        self.clock() + self.empty_ttl, (), code, ())
                    self.cache.move_to_end((self.identity, self.focus_item))
                    while len(self.cache) > self.capacity:
                        self.cache.popitem(last=False)
                self._finish((), code)
        if self.state != 'loading':
            return
        key = self._key()
        if key in self.jobs:
            return
        cached = self.cache.get((self.identity, self.focus_item))
        if cached and self.revision == 0 and cached[0] > self.clock():
            started = self.clock()
            self.metrics['memory_hit'] += 1
            self.cache.move_to_end((self.identity, self.focus_item))
            self._finish(cached[1], cached[2], cached[3])
            self._sample('memory_hit', started)
            return
        # A validated memory hit does no I/O and must not inherit the cold
        # request debounce. Keep that delay for disk/network work only.
        if self.clock() < self.ready_at:
            return
        if len(self.jobs) < 2:
            try:
                submit_keyed = getattr(self.executor, 'submit_keyed', None)
                if submit_keyed:
                    shared_key = (id(self.fetch), self.identity, self.focus_item, self.revision,
                                  self.cache_generation[0], self.cache_namespace)
                    self.jobs[key] = submit_keyed(shared_key, self._fetch,
                                                  self.identity, self.focus_item, self.revision)
                else:
                    self.jobs[key] = self.executor.submit(self._fetch, self.identity, self.focus_item, self.revision)
            except RequestBusy:
                return  # Retry on the next pump, within the existing deadline.
            except Exception:
                self._finish((), 'connection_failed')

    def diagnostics(self):
        # Build from known fields, never from exception text or arbitrary input.
        with self.metric_lock:
            samples = {name: sorted(values) for name, values in self.latencies.items()}
        latency = {name: {'count': len(values),
                         'p50_ms': values[math.ceil(len(values) * .50) - 1] if values else None,
                         'p95_ms': values[math.ceil(len(values) * .95) - 1] if values else None}
                   for name, values in samples.items()}
        return {'state': self.state, 'reason': self.error, 'slots': len(self.values),
                'cached_items': len(self.cache), 'in_flight': len(self.jobs),
                'cache_counts': dict(self.metrics),
                'latency_ms': latency,
                'rejected': {code: self.rejected.count(code) for code in sorted(set(self.rejected))}}

    def close(self):
        self.invalidate()
        self.closed = True
        # A keyed future may still belong to another live row/focus engine.
        if not hasattr(self.executor, 'submit_keyed'):
            for future in self.jobs.values():
                future.cancel()
        if self.owns_executor:
            self.executor.shutdown(wait=False)
