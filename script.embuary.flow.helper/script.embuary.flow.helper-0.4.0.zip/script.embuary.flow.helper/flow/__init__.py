"""Flow core policies and initial Kodi/Jellyfin adapters; device acceptance pending."""
