"""Bounded nearby episode scores; no library scan or unbounded work queue."""
import time
import datetime
import re
from collections import OrderedDict

from .ratings import Ratings, RatingsError, slots

ROW_LIMIT = 11
DATE_CACHE_LIMIT = 1024


def valid_premiered(value):
    """Only an actual Gregorian ISO date; no show-level or localized fallback."""
    if not isinstance(value, str) or not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', value):
        return ''
    try:
        datetime.date.fromisoformat(value)
    except ValueError:
        return ''
    return value


class EpisodeRows:
    def __init__(self, home, video=None, clock=time.monotonic):
        self.home, self.video, self.clock = home, video, clock
        self.scope = None
        self.items = ()
        self.engines = {}
        self.previous = {}
        self.retry_at = {}
        self.mapped_items = OrderedDict()
        self.published = {}
        self.indices = {}
        self.prefilter_published = {}
        self.dates = OrderedDict()
        self.date_published = {}
        self.ready_at = 0
        self.clear(initial=True)

    def clear(self, initial=False, only=None):
        # A service restart clears all potentially stale skin properties once.
        # Subsequent scrolls clear only slots actually published by this service.
        indices = ({index: 8 for index in range(ROW_LIMIT)} if initial else
                   dict(self.published) if only is None else
                   {index: self.published.get(index, 0) for index in only})
        date_indices = (range(ROW_LIMIT) if initial else
                        list(self.date_published) if only is None else only)
        for index in date_indices:
            self.date_published.pop(index, None)
            for window in (self.home, self.video):
                if window is not None:
                    window.clearProperty('Flow.EpisodeDate.%d.DBID' % index)
                    window.clearProperty('Flow.EpisodeDate.%d.Premiered' % index)
        for index, count in indices.items():
            self.home.clearProperty('Flow.EpisodeRow.%d.DBID' % index)
            self.home.clearProperty('Flow.EpisodeRow.%d.Count' % index)
            for slot in range(1, count + 1):
                for suffix in ('', '.Platform', '.Value', '.Source'):
                    self.home.clearProperty('Flow.EpisodeRow.%d.%d%s' % (index, slot, suffix))
            self.previous.pop(index, None)
            self.published.pop(index, None)
        if only is None:
            self.dates.clear()
            self.previous.clear()
            self.published.clear()

        self.sync_filters(initial=initial)

    def sync_filters(self, extra=(), initial=False):
        """Keep necessary skin prechecks a superset of committed row identities.

        Add incoming memberships before committing a row; discard obsolete
        memberships only after its old identity has been cleared. Exact row
        guards still decide every score, including substring collisions.
        """
        bindings = [(dbid, self.published[index]) for dbid, index in self.indices.items()
                    if index in self.published] + list(extra)
        filters = {}
        for kind, bounds in (('Slot', range(1,9)), ('Count', range(1,9)), ('Below', range(2,9))):
            for number in bounds:
                ids = sorted({str(dbid) for dbid, count in bindings if
                              (count >= number if kind == 'Slot' else
                               count == number if kind == 'Count' else count < number)})
                filters[kind + str(number)] = '|'.join(ids)
        for name, value in filters.items():
            key = 'Flow.EpisodeRows.Filter.' + name
            if value:
                if self.prefilter_published.get(name) != value:
                    self.home.setProperty(key, value)
            elif initial or self.prefilter_published.get(name):
                self.home.clearProperty(key)
        self.prefilter_published = filters

    def reset(self):
        if self.scope is None and not self.items and not self.engines and not self.previous:
            return
        self.clear()
        for engine in self.engines.values():
            engine.cache = OrderedDict()
            engine.close()
        self.engines.clear()
        self.retry_at.clear()
        self.mapped_items.clear()
        self.indices.clear()
        self.dates.clear()
        self.scope, self.items = None, ()

    def publish_dates(self, items, allowed):
        pending = [(self.indices[dbid], dbid, self.dates[dbid]) for dbid in items
                   if dbid in self.dates and
                   self.date_published.get(self.indices[dbid]) != (dbid, self.dates[dbid])]
        if pending and not allowed():
            self.reset()
            return
        for index, dbid, value in pending:
            key = 'Flow.EpisodeDate.%d' % index
            for window in (self.home, self.video):
                if window is not None:
                    window.clearProperty(key + '.DBID')
                    window.clearProperty(key + '.Premiered')
                    if value:
                        window.setProperty(key + '.Premiered', value)
                        window.setProperty(key + '.DBID', str(dbid))
            self.date_published[index] = (dbid, value)
            self.dates.move_to_end(dbid)

    def update(self, scope, items, base, mapping, options, publish_allowed, context_allowed=None, date_reader=None):
        items = tuple(dict.fromkeys(items))[:ROW_LIMIT]
        if scope != self.scope:
            self.reset()
            self.scope = scope
        if items != self.items:
            departed = set(self.indices) - set(items)
            self.clear(only=[self.indices.pop(dbid) for dbid in departed])
            # Retain stable property slots for rows still in the neighborhood.
            # Reordering/one-step scrolling no longer clears every score.
            available = [index for index in range(ROW_LIMIT) if index not in self.indices.values()]
            for dbid in items:
                if dbid not in self.indices:
                    self.indices[dbid] = available.pop(0)
            for dbid in set(self.engines) - set(items):
                retired = self.engines.pop(dbid)
                retired.cache = OrderedDict()
                retired.close()
            self.retry_at = {dbid: deadline for dbid, deadline in self.retry_at.items() if dbid in items}
            # Keep a bounded mapping history within this exact identity/folder
            # scope, so returning warm rows need no disk read or cold debounce.
            self.items = items
            self.ready_at = self.clock() + .4
        allowed = publish_allowed if callable(publish_allowed) else lambda: publish_allowed
        if not (context_allowed or allowed)():
            self.reset()
            return
        # Date is local metadata, not an asynchronous score. Restore an
        # already-seen row immediately, even during the score debounce.
        self.publish_dates(items, allowed)
        if self.scope is None:
            return
        warm_only = self.clock() < self.ready_at
        missing_dates = tuple(dbid for dbid in items if dbid not in self.dates)
        if not warm_only and missing_dates and date_reader is not None:
            try:
                dates = date_reader(missing_dates)
            except (ValueError, KeyError, TypeError):
                dates = {}
            if not allowed():
                self.reset()
                return
            for dbid in missing_dates:
                value = valid_premiered(dates.get(dbid))
                self.dates[dbid] = value
                self.dates.move_to_end(dbid)
            while len(self.dates) > DATE_CACHE_LIMIT:
                self.dates.popitem(last=False)
            self.publish_dates(items, allowed)
            if self.scope is None:
                return
        order, hidden, limit, _ = options
        admitted = 0
        for dbid in items:
            index = self.indices[dbid]
            item = self.mapped_items.get(dbid)
            cached = base.cache.get((base.identity, item)) if item else None
            if warm_only and not (cached and cached[0] > self.clock()):
                continue  # Cold mappings and requests still wait for stable focus.
            engine = self.engines.get(dbid)
            if engine is None:
                if item is None:
                    if admitted >= 2 or self.clock() < self.retry_at.get(dbid, 0):
                        continue
                    admitted += 1
                    try:
                        item = 'episode:' + mapping.resolve('episode', dbid)
                    except RatingsError:
                        self.retry_at[dbid] = self.clock() + 1.5
                        continue
                    self.mapped_items[dbid] = item
                self.mapped_items.move_to_end(dbid)
                while len(self.mapped_items) > base.capacity:
                    self.mapped_items.popitem(last=False)
                cached = base.cache.get((base.identity, item))
                # Cache and focused results remain usable when both workers
                # are busy. A cold row gets no deadline until it can submit.
                if (base.executor.active >= 2 and base.focus_item != item and
                        not (cached and cached[0] > self.clock())):
                    continue
                engine = Ratings(base.fetch, clock=self.clock, executor=base.executor,
                                 persistent=base.persistent, cache_namespace=base.cache_namespace)
                engine.switch_identity(base.identity)
                # One LRU is shared with focused scores; no duplicate API read
                # after navigating between a row and the same focused episode.
                engine.cache = base.cache
                engine.cache_generation = base.cache_generation
                engine.focus(item)
                # The row scheduler already waited for stable GUI identities.
                # Submit now, rather than admitting many debouncing engines
                # whose result deadlines would expire before a worker is free.
                engine.ready_at = self.clock()
                engine.deadline = self.clock() + engine.result_timeout
                self.engines[dbid] = engine
            if engine.focus_item == base.focus_item:
                engine.state, engine.values, engine.error = base.state, base.values, base.error
            else:
                engine.pump()
            if engine.error == 'auth_failed':
                self.reset()
                base.invalidate()
                raise RatingsError('auth_failed')
            values, _ = slots(engine.values, order, hidden, limit)
            if engine.state != 'ready':
                values = []
            snapshot = tuple((v['source'], v['label'], v['value']) for v in values) if engine.state == 'ready' else ()
            if self.previous.get(index) == snapshot:
                continue
            if not allowed():
                self.reset()
                return
            if snapshot:
                self.sync_filters(extra=((dbid, len(values)),))
            # Identity is removed before replacing values and committed last.
            key = 'Flow.EpisodeRow.%d' % index
            self.home.clearProperty(key + '.DBID')
            self.home.clearProperty(key + '.Count')
            labels = {'rt_critics': 'RT 影评', 'rt_audience': 'RT 观众'}
            for slot in range(1, self.published.pop(index, 0) + 1):
                for suffix in ('', '.Platform', '.Value', '.Source'):
                    self.home.clearProperty(key + '.%d%s' % (slot, suffix))
            for slot, value in enumerate(values, 1):
                platform = labels.get(value['source'], value['label'])
                self.home.setProperty(key + '.%d' % slot,
                                      platform + '  ' + value['value'])
                self.home.setProperty(key + '.%d.Platform' % slot, platform)
                self.home.setProperty(key + '.%d.Value' % slot, value['value'])
                self.home.setProperty(key + '.%d.Source' % slot, value['source'])
            if snapshot:
                self.published[index] = len(values)
                self.home.setProperty(key + '.Count', str(len(values)))
                self.home.setProperty(key + '.DBID', str(dbid))
                engine.mark_published()
            self.previous[index] = snapshot
            self.sync_filters()
