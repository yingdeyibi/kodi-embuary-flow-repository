"""Enable the selected subtitle once per AV start, including delayed streams.

Callbacks only arm/cancel work. The service thread performs the player write;
after success or timeout, manual subtitle changes are left alone.
"""
from threading import RLock
import time


def startup_player(xbmc, skin, clock=time.monotonic):
    class StartupPlayer(xbmc.Player):
        def __init__(self):
            super().__init__()
            self._lock = RLock()
            self._deadline = None

        def cancel(self):
            with self._lock:
                self._deadline = None

        def onPlayBackStarted(self):
            self.cancel()

        def onAVStarted(self):
            with self._lock:
                self._deadline = clock() + 15.0 if xbmc.getSkinDir() == skin else None

        def onPlayBackStopped(self):
            self.cancel()

        def onPlayBackEnded(self):
            self.cancel()

        def onPlayBackError(self):
            self.cancel()

        def tick(self):
            with self._lock:
                if self._deadline is None:
                    return
                if clock() >= self._deadline or xbmc.getSkinDir() != skin:
                    self._deadline = None
                    return
                try:
                    if not self.isPlayingVideo():
                        return
                    if not self.getAvailableSubtitleStreams():
                        return
                    if not xbmc.getCondVisibility('VideoPlayer.SubtitlesEnabled'):
                        self.showSubtitles(True)
                    self._deadline = None
                except Exception:
                    # Streams/player may disappear between the native calls.
                    # Retry only within this startup's bounded window.
                    return

    return StartupPlayer()
