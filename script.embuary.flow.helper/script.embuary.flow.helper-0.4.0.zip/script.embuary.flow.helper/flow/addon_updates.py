"""Read Kodi 21's update list and cache; never change addon files or rules."""
import json
from pathlib import Path
import sqlite3

from .storage import write_json

PROTECTED = {
    'script.embuary.helper': 'Embuary Helper',
    'script.embuary.info': 'Embuary Info',
    'service.upnext': 'Up Next',
    'plugin.video.jellyfin': 'Jellyfin for Kodi',
}


def pending_updates(result):
    if (not isinstance(result, (tuple, list)) or len(result) != 2 or
            not all(isinstance(part, list) and all(isinstance(v, str) for v in part)
                    for part in result)):
        raise ValueError('invalid_update_list')
    return set(result[0] + result[1]) & PROTECTED.keys()


def cache_status(database):
    """Read one consistent snapshot. mode=ro also prevents creating a missing DB."""
    connection = sqlite3.connect(Path(database).resolve().as_uri() + '?mode=ro',
                                 uri=True, timeout=1)
    try:
        connection.execute('BEGIN')
        installed = {row[0] for row in connection.execute('SELECT addonID FROM installed')}
        pinned = {row[0] for row in connection.execute('SELECT addonID FROM update_rules')}
        versions = {addon: set() for addon in PROTECTED if addon in installed}
        rows = connection.execute('''SELECT a.addonID, r.addonID, a.version FROM addons a
            JOIN addonlinkrepo l ON l.idAddon=a.id JOIN repo r ON r.id=l.idRepo
            JOIN installed i ON i.addonID=r.addonID WHERE i.enabled=1''')
        for addon, repository, version in rows:
            if addon in versions:
                versions[addon].add(repository + ':' + version)
        return versions, pinned
    finally:
        connection.close()


class UpdateWatcher:
    def __init__(self, database, state, listdir, notify, log):
        self.database, self.state = Path(database), Path(state)
        self.listdir, self.notify, self.log = listdir, notify, log
        self.next_check = 60.0
        self.started = None
        self.error = None

    def check(self):
        pending = pending_updates(self.listdir('addons://outdated/'))
        versions, pinned = cache_status(self.database)
        try:
            seen = json.loads(self.state.read_text('utf-8'))
        except FileNotFoundError:
            seen = {}
        if not isinstance(seen, dict) or any(
                not isinstance(value, list) or not all(isinstance(v, str) for v in value)
                for value in seen.values()):
            raise ValueError('invalid_update_reminder_state')
        messages = []
        for addon, candidates in versions.items():
            if addon in pending:
                if not candidates:
                    raise ValueError('update_cache_incomplete')
                if candidates - set(seen.get(addon, [])):
                    messages.append(PROTECTED[addon])
        if messages:
            self.notify('、'.join(messages) + ' 有新版；请先核对补丁兼容性，暂勿直接更新。')
            for addon in pending & versions.keys():
                seen[addon] = sorted(set(seen.get(addon, [])) | versions[addon])
            write_json(self.state, seen)
        return versions.keys() - pinned

    def tick(self, now, idle):
        if self.started is None:
            self.started = now
        if not idle or now - self.started < self.next_check:
            return
        self.next_check = now - self.started + 1800
        try:
            unprotected = self.check()
            if unprotected:
                self.log('Flow addon updates: auto updates not disabled for ' +
                         ', '.join(sorted(unprotected)))
            self.error = None
        except (OSError, ValueError, RuntimeError, sqlite3.Error) as exc:
            code = type(exc).__name__
            if code != self.error:
                self.log('Flow addon update check failed: ' + code)
            self.error = code


def guide(xbmc, gui, vfs):
    """Only explicit user actions open Kodi's native addon browser."""
    if xbmc.getCondVisibility('Player.HasMedia'):
        gui.Dialog().ok('Flow 插件更新保护', '请停止播放后再设置插件自动更新。')
        return
    addons = list(PROTECTED)
    choice = gui.Dialog().select('选择插件，关闭其自动更新', list(PROTECTED.values()))
    if choice < 0:
        return
    addon = addons[choice]
    directory = None
    for candidate in ('addons://user/all/', 'addons://dependencies/'):
        directories, files = vfs.listdir(candidate)
        if addon in directories + files:
            directory = candidate
            break
    if directory is None:
        gui.Dialog().ok('Flow 插件更新保护', '未在 Kodi 插件列表找到 ' + PROTECTED[addon])
        return
    if gui.Dialog().ok('Flow 插件更新保护',
                       '在接下来的列表中打开 ' + PROTECTED[addon] +
                       '，关闭“自动更新”。若全局已关闭自动更新，无需重复设置。'
                       '\n此引导不代表开关已经关闭；其他插件保持原设置。'):
        xbmc.executebuiltin('ActivateWindow(AddonBrowser,' + directory + ',return)')


def show_status(gui, vfs):
    try:
        versions, pinned = cache_status(vfs.translatePath('special://database/Addons33.db'))
        pending = pending_updates(vfs.listdir('addons://outdated/'))
        lines = []
        for addon, name in PROTECTED.items():
            state = ('未安装' if addon not in versions else
                     '已禁止自动更新' if addon in pinned else '未单独关闭自动更新')
            lines.append(name + '：' + state + ('；有新版' if addon in pending else ''))
        lines.append('新版信息以 Kodi 仓库缓存为准；全局更新开关另计。')
        gui.Dialog().ok('Flow 插件更新保护', '\n'.join(lines))
    except (OSError, ValueError, RuntimeError, sqlite3.Error):
        gui.Dialog().ok('Flow 插件更新保护', '读取失败；请检查 Kodi 插件仓库及 Addons33.db 是否可读。')
