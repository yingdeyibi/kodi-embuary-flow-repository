"""Profile-local bounded SQLite ratings, accessed only by background workers.

No credentials, URLs, titles or raw provider payloads are persisted. A stable
hashed namespace includes the authentication epoch, but not mapping file mtime.
"""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sqlite3
import threading
import time
import uuid

from .ratings import Rating, RatingResult, REJECTION_CODES, SOURCES, RATING_TTL

SCHEMA = 1
ADAPTER = 1
CAPACITY = 20000
SESSION_LOCK = threading.RLock()


@dataclass(frozen=True)
class CachedResult:
    result: RatingResult
    remaining: float
    error: str = None


def namespace(identity):
    return hashlib.sha256(json.dumps((identity.profile, identity.server, identity.user,
                                     identity.library_generation)).encode()).hexdigest()


def timestamp(value):
    if not isinstance(value, str) or len(value) > 64:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            return None
        return parsed.astimezone(timezone.utc).isoformat()
    except ValueError:
        return None


class PersistentRatings:
    def __init__(self, path, capacity=CAPACITY, clock=time.time, max_ttl=RATING_TTL):
        if type(capacity) is not int or capacity < 1:
            raise ValueError('invalid_capacity')
        self.path, self.capacity, self.clock = Path(path), capacity, clock
        if type(max_ttl) not in (int, float) or not math.isfinite(max_ttl) or max_ttl <= 0:
            raise ValueError('invalid_ttl')
        self.max_ttl = max_ttl
        self.lock = threading.Lock()
        self.disabled = False
        self.blocked = set()
        self.epochs = {}
        self.invalidated = set()
        self.pending = {}
        self.running = False
        self.closed = False
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix='flow-cache-write')
        self.counts = dict(disk_hit=0, disk_miss=0, writes=0, failures=0)
        self.marker = self.path.with_suffix(self.path.suffix + '.unclean')
        self.session = uuid.uuid4().hex
        self.startup = self.executor.submit(self._initialize)

    def _owns_session(self):
        return self.marker.read_text(encoding='ascii') == self.session

    def _initialize(self):
        with SESSION_LOCK:
            return self._initialize_locked()

    def _initialize_locked(self):
        db = None
        staging = self.marker.with_name(self.marker.name + '.' + self.session)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            unclean = self.marker.exists()
            # Independent of SQLite locks: persist before admitting any read.
            with staging.open('x', encoding='ascii') as stream:
                stream.write(self.session)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(staging, self.marker)
            db = self._open_connect()
            if unclean:
                with db:
                    db.execute('DELETE FROM ratings')
                    db.execute('DELETE FROM revoked')
            return True
        except (sqlite3.Error, OSError):
            self._failed()
            return False
        finally:
            if db is not None:
                db.close()
            if staging.exists():
                staging.unlink()

    def _connect(self):
        if not self.startup.result() or not self._owns_session():
            raise sqlite3.DatabaseError('cache_session_unavailable')
        return self._open_connect()

    def _open_connect(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(str(self.path), timeout=0.15)
        try:
            version = db.execute('PRAGMA user_version').fetchone()[0]
            if version not in (0, SCHEMA):
                raise sqlite3.DatabaseError('incompatible_schema')
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('PRAGMA synchronous=NORMAL')
            db.execute('CREATE TABLE IF NOT EXISTS ratings(namespace TEXT, item TEXT, adapter INTEGER, '
                       'checked REAL, expires REAL, cached_at TEXT, digest TEXT, body TEXT, '
                       'PRIMARY KEY(namespace,item))')
            db.execute('CREATE TABLE IF NOT EXISTS revoked(namespace TEXT PRIMARY KEY)')
            db.execute('PRAGMA user_version=%d' % SCHEMA)
            db.commit()
            return db
        except Exception:
            db.close()
            raise

    def _failed(self):
        with self.lock:
            self.disabled = True
            self.counts['failures'] += 1

    def read(self, space, item):
        with self.lock:
            if self.closed or self.disabled or space in self.blocked or (space, item) in self.invalidated:
                return None
        db = None
        try:
            db = self._connect()
            if db.execute('SELECT 1 FROM revoked WHERE namespace=?', (space,)).fetchone():
                return None
            row = db.execute('SELECT adapter,checked,expires,digest,body FROM ratings '
                             'WHERE namespace=? AND item=?', (space, item)).fetchone()
            now = self.clock()
            if not row or row[0] != ADAPTER or not math.isfinite(now):
                self.counts['disk_miss'] += 1
                return None
            adapter, checked, expires, digest, body = row
            if (not all(type(v) in (int, float) and math.isfinite(v) for v in (checked, expires))
                    or checked > now + 1 or not checked <= now < expires
                    or expires - checked > self.max_ttl or not isinstance(body, str) or len(body) > 32768
                    or hashlib.sha256(body.encode()).hexdigest() != digest):
                self.counts['disk_miss'] += 1
                return None
            data = json.loads(body)
            values = tuple(Rating(**record) for record in data['ratings'])
            if (len(values) > len(SOURCES) or len({v.source for v in values}) != len(values)
                    or any(v.source not in SOURCES or type(v.value) not in (int, float)
                           or not math.isfinite(v.value) or not 0 <= v.value <= SOURCES[v.source][1]
                           or v.scale != SOURCES[v.source][1]
                           or (v.votes is not None and (type(v.votes) is not int or v.votes < 0))
                           for v in values)
                    or data['error'] not in (None, 'no_cache')
                    or (data['error'] is not None and values)
                    or any(code not in REJECTION_CODES for code in data['rejected'])):
                raise ValueError('invalid_record')
            with self.lock:
                if self.closed or self.disabled or space in self.blocked or (space, item) in self.invalidated:
                    return None
                self.counts['disk_hit'] += 1
            return CachedResult(RatingResult(values, tuple(data['rejected'])), expires - now, data['error'])
        except (sqlite3.Error, OSError, ValueError, TypeError, KeyError):
            self._failed()
            return None
        finally:
            if db is not None:
                db.close()

    def write(self, space, item, result, ttl, cached_at=None, error=None, authenticated=False):
        # Called only after the current request's UI identity checks pass.
        checked = self.clock()
        if not math.isfinite(checked) or not 0 < ttl <= self.max_ttl:
            return
        body = json.dumps({'ratings': [v.__dict__ for v in result.ratings],
                           'rejected': list(result.rejected), 'error': error},
                          sort_keys=True, separators=(',', ':'), allow_nan=False)
        entry = (space, item, ADAPTER, checked, checked + ttl, timestamp(cached_at),
                 hashlib.sha256(body.encode()).hexdigest(), body)
        with self.lock:
            if self.closed or self.disabled or (space in self.blocked and not authenticated):
                return
            if len(self.pending) >= 256 and (space, item) not in self.pending:
                # Never evict a queued refresh deletion: that could resurrect
                # its old disk value after a failed refresh or a restart.
                self.disabled = True
                self.counts['failures'] += 1
                return
            self.pending[(space, item)] = (entry, self.epochs.get(space, 0), authenticated)
            self.invalidated.add((space, item))
            self._schedule()

    def forget(self, space, item):
        with self.lock:
            if self.closed or self.disabled:
                return
            if len(self.pending) >= 256 and (space, item) not in self.pending:
                # Collapse this namespace's queued work into a durable revoke.
                # Saturation must never leave old disk values eligible again.
                self._revoke_locked(space)
                return
            self.invalidated.add((space, item))
            self.pending[(space, item)] = None
            self._schedule()

    def revoke(self, space):
        with self.lock:
            if self.closed:
                return
            self._revoke_locked(space)

    def _revoke_locked(self, space):
        self.blocked.add(space)
        self.epochs[space] = self.epochs.get(space, 0) + 1
        self.pending = {key: value for key, value in self.pending.items() if key[0] != space}
        self.invalidated = {key for key in self.invalidated if key[0] != space}
        self.pending[(space, None)] = None
        self._schedule()

    def _schedule(self):
        if not self.running and not self.closed and not self.disabled:
            self.running = True
            self.executor.submit(self._drain)

    def _drain(self):
        db = None
        batch = []
        try:
            db = self._connect()
            while True:
                with self.lock:
                    batch = list(self.pending.items())[:32]
                    for key, _ in batch:
                        self.pending.pop(key, None)
                    if not batch:
                        self.running = False
                        return
                with db:
                    if not self._owns_session():
                        raise sqlite3.DatabaseError('cache_session_replaced')
                    resumed = []
                    cleared = set()
                    for (space, item), entry in batch:
                        with self.lock:
                            blocked = space in self.blocked
                        if entry is None and item is None:
                            db.execute('INSERT OR IGNORE INTO revoked VALUES(?)', (space,))
                            db.execute('DELETE FROM ratings WHERE namespace=?', (space,))
                        elif entry is None:
                            db.execute('DELETE FROM ratings WHERE namespace=? AND item=?', (space, item))
                        else:
                            row, epoch, authenticated = entry
                            with self.lock:
                                current = epoch == self.epochs.get(space, 0)
                            if not current or (blocked and not authenticated):
                                continue
                            if authenticated:
                                # Clear revoked data before admitting the
                                # freshly authenticated result. Never restore
                                # any old record when credentials work again.
                                revoked = db.execute('SELECT 1 FROM revoked WHERE namespace=?', (space,)).fetchone()
                                if (blocked or revoked) and space not in cleared:
                                    db.execute('DELETE FROM ratings WHERE namespace=?', (space,))
                                    db.execute('DELETE FROM revoked WHERE namespace=?', (space,))
                                    cleared.add(space)
                                resumed.append((space, epoch))
                            db.execute('INSERT OR REPLACE INTO ratings VALUES(?,?,?,?,?,?,?,?)', row)
                            self.counts['writes'] += 1
                    db.execute('DELETE FROM ratings WHERE expires<=?', (self.clock(),))
                    db.execute('DELETE FROM ratings WHERE rowid IN (SELECT rowid FROM ratings '
                               'ORDER BY checked DESC LIMIT -1 OFFSET ?)', (self.capacity,))
                with self.lock:
                    for space, epoch in resumed:
                        if epoch == self.epochs.get(space, 0):
                            self.blocked.discard(space)
                    for key, _ in batch:
                        if key not in self.pending:
                            self.invalidated.discard(key)
        except Exception:
            self._failed()
            with self.lock:
                # Keep failed invalidations; the durable unclean marker also
                # prevents old values from surviving a restart.
                for key, entry in batch:
                    if key not in self.pending:
                        self.pending[key] = entry
                self.running = False
        finally:
            if db is not None:
                try:
                    db.close()
                except Exception:
                    self._failed()

    def close(self, wait=False):
        with self.lock:
            if self.closed:
                already_closed = True
            else:
                already_closed = False
                self.closed = True
        if not already_closed:
            self.executor.submit(self._finish_session)
        self.executor.shutdown(wait=wait)

    def _finish_session(self):
        # Ordered after startup and all scheduled writes on the same worker.
        with self.lock:
            clean = not self.disabled and not self.pending and not self.running
        try:
            if clean and self.startup.result():
                with SESSION_LOCK:
                    if self._owns_session():
                        self.marker.unlink()
        except (OSError, sqlite3.Error):
            self._failed()
