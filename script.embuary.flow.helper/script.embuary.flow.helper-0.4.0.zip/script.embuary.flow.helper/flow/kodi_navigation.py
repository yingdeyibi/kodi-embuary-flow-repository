"""Bounded identity search for the native Kodi video list.

Uses audited container InfoLabels, never Python ControlList enumeration or a
JSON-RPC order guessed to match the GUI. Kodi owns the native return history.
"""
import time


VIEWS = (50, 51, 52, 53, 54, 59, 55, 56, 58)
SCAN_BATCH = 512


def read_batch(container, start, count, rpc):
    """Read GUI order in one GUI dispatch; never use VideoLibrary result order."""
    stop = min(start + SCAN_BATCH, count)
    keys = {position: ('Container(%d).ListItemAbsolute(%d).DBTYPE' % (container, position),
                       'Container(%d).ListItemAbsolute(%d).DBID' % (container, position))
            for position in range(start, stop)}
    labels = rpc('XBMC.GetInfoLabels', {'labels': [key for pair in keys.values() for key in pair]})
    if not isinstance(labels, dict):
        raise ValueError('invalid_gui_labels')
    result = {}
    for position, (type_key, id_key) in keys.items():
        media_type, dbid = labels.get(type_key), labels.get(id_key)
        if not isinstance(media_type, str) or not isinstance(dbid, str):
            raise ValueError('incomplete_gui_labels')
        value = int(dbid) if dbid.isascii() and dbid.isdecimal() and len(dbid) <= 10 else 0
        result[position] = (media_type, value if 0 < value <= 2147483647 else 0)
    return result


def destination(media_type, dbid, rpc):
    if type(dbid) is not int or not 0 < dbid <= 2147483647:
        raise ValueError('invalid_identity')
    if media_type == 'movie':
        result = rpc('VideoLibrary.GetMovieDetails', {'movieid': dbid})
        if result.get('moviedetails', {}).get('movieid') != dbid:
            raise ValueError('missing_movie')
        return 'videodb://movies/titles/'
    if media_type == 'episode':
        result = rpc('VideoLibrary.GetEpisodeDetails', {
            'episodeid': dbid, 'properties': ['tvshowid', 'season']}).get('episodedetails', {})
        show, season = result.get('tvshowid'), result.get('season')
        if (type(result.get('episodeid')) is not int or result.get('episodeid') != dbid
                or type(show) is not int or not 0 < show <= 2147483647
                or type(season) is not int or not 0 <= season <= 2147483647):
            raise ValueError('missing_episode')
        return 'videodb://tvshows/titles/%d/%d/' % (show, season)
    raise ValueError('unsupported_media')


class Locator:
    """One-shot search. Adapter cancels on window, context or user focus change."""
    def __init__(self, media_type, dbid, clock=time.monotonic, timeout=4.0):
        self.media_type, self.dbid, self.clock = media_type, dbid, clock
        self.deadline = clock() + timeout
        self.cursor = 0
        self.snapshot = None
        self.done = False

    def cancel(self):
        self.done = True

    def step(self, container, count, context, focused, read_identity, batch=SCAN_BATCH):
        if self.done or self.clock() >= self.deadline:
            self.done = True
            return None
        current = (container, count, context, focused)
        if self.snapshot is None:
            self.snapshot = current
        elif current != self.snapshot:
            self.cancel()
            return None
        if container not in VIEWS or type(count) is not int or not 0 < count <= 100000:
            self.cancel()
            return None
        stop = min(self.cursor + batch, count)
        while self.cursor < stop:
            if self.clock() >= self.deadline:
                self.cancel()
                return None
            position = self.cursor
            self.cursor += 1
            identity = read_identity(container, position)
            if self.clock() >= self.deadline:
                self.cancel()
                return None
            if identity == (self.media_type, self.dbid):
                self.done = True
                return position
        if self.cursor >= count:
            self.done = True
        return None
