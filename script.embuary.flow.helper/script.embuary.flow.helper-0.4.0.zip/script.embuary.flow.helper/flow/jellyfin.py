"""Read-only adapter for Jellyfin for Kodi 2.2.0's local database/config.

The single-server restriction is intentional: jellyfin.db has no server column.
Never log the config, connection, SQL rows or exception messages.
"""
from dataclasses import dataclass, field
import hashlib
import json
from pathlib import Path
import sqlite3
import uuid

from .connection import CacheClient
from .ratings import Identity, RatingsError


def digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


@dataclass(frozen=True)
class Connection:
    server: str
    user: str
    url: str = field(repr=False)
    token: str = field(repr=False)

    def identity(self, profile, generation):
        # Token rotation also retires all old results; secrets never leave memory.
        return Identity(digest(profile), digest(self.server + self.url), self.user,
                        digest(generation + self.token))


def read_connection(path):
    return ConnectionReader()(path)


class ConnectionReader:
    """Service-owned, one-entry cache keyed by exact file bytes, not mtime.

    Every publication still reads credentials: same-size/token replacements
    and timestamp-preserving writes must retire the old identity immediately.
    Only JSON parsing and transport construction are skipped on an exact hit.
    """
    def __init__(self):
        self._raw = self._connection = None

    def __call__(self, path):
        try:
            with Path(path).open('rb') as stream:
                raw = stream.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                raise ValueError()
            if self._connection is not None and raw == self._raw:
                return self._connection
            connection = parse_connection(raw)
        except (OSError, ValueError, TypeError):
            self._raw = self._connection = None
            raise RatingsError('not_configured') from None
        except RatingsError:
            self._raw = self._connection = None
            raise
        self._raw, self._connection = raw, connection
        return connection


def parse_connection(raw):
    try:
        config = json.loads(raw)
        servers = config.get('Servers') if isinstance(config, dict) else None
        if not isinstance(servers, list) or len(servers) != 1:
            raise ValueError()
        server = servers[0]
        if not isinstance(server, dict) or not all(
                isinstance(server.get(k), str) and server[k]
                for k in ('Id', 'UserId', 'address', 'AccessToken')):
            raise ValueError()
        CacheClient(server['address'], server['AccessToken'])  # validate transport
        return Connection(server['Id'], server['UserId'], server['address'], server['AccessToken'])
    except (OSError, ValueError, TypeError):
        raise RatingsError('not_configured') from None


class MappingItemMissing(RatingsError):
    """A valid database has no row for this focused item."""

    def __init__(self):
        super().__init__('mapping_missing')


class Mapping:
    def __init__(self, path):
        self.path = Path(path).resolve()

    def generation(self):
        """Detect replacement, writes and WAL updates, without reading media data."""
        try:
            parts = []
            for path in (self.path, Path(str(self.path) + '-wal')):
                if path.exists():
                    stat = path.stat()
                    parts.append((stat.st_ino, stat.st_size, stat.st_mtime_ns))
            if not parts:
                raise OSError()
            return repr(parts)
        except OSError:
            raise RatingsError('mapping_missing') from None

    def resolve(self, media_type, dbid):
        if media_type not in ('movie', 'episode', 'tvshow', 'season') or type(dbid) is not int or dbid <= 0:
            raise RatingsError('mapping_missing')
        try:
            connection = sqlite3.connect(self.path.as_uri() + '?mode=ro', uri=True, timeout=0.1)
            try:
                connection.execute('PRAGMA query_only=ON')
                rows = connection.execute(
                    'SELECT jellyfin_id FROM jellyfin WHERE kodi_id=? AND media_type=? LIMIT 2',
                    (dbid, media_type)).fetchall()
            finally:
                connection.close()
            if not rows:
                raise MappingItemMissing()
            if len(rows) != 1:
                raise ValueError()
            item = uuid.UUID(rows[0][0])
            if not item.int:
                raise ValueError()
            return item.hex
        except (sqlite3.Error, OSError, ValueError, TypeError, AttributeError):
            raise RatingsError('mapping_missing') from None
