"""CachedByItemId adapter for the recorded 2026-10-06 payload contract.

Includes the corroborated 2026-10-09 season/episode TMDb value/score pairs.
This is not a universal MDBList API decoder. Unknown sources are reported and
hidden until their native scales have been verified. No fallback to score or
Jellyfin's generic CommunityRating is allowed. See docs/DEVICE-FIXES.md.
"""
from dataclasses import dataclass
import math

from .ratings import Rating, RatingResult, RatingsError, SOURCES


# wire source -> normalized ID, wire value scale. TMDb's cache value was 75,
# not 7.5; convert the declared /100 wire scale to the existing /10 UI scale.
CONTRACT = {
    'imdb': ('imdb', 10),
    'tmdb': ('tmdb', 100),
    'tomatoes': ('rt_critics', 100),
    'popcorn': ('rt_audience', 100),
    'metacritic': ('metacritic', 100),
    'trakt': ('trakt', 100),
    'letterboxd': ('letterboxd', 5),
}


@dataclass(frozen=True)
class ParsedRatings:
    ratings: tuple
    rejected: tuple  # fixed diagnostic codes only; never raw API content


def parse_cached(payload):
    if not isinstance(payload, dict) or type(payload.get('hasCache')) is not bool:
        raise RatingsError('invalid_data')
    if not payload['hasCache']:
        raise RatingsError('no_cache')
    records = payload.get('ratings')
    if not isinstance(records, list):
        raise RatingsError('invalid_data')
    values, rejected, seen = [], [], set()
    for record in records:
        if not isinstance(record, dict) or not isinstance(record.get('source'), str):
            rejected.append('invalid_record')
            continue
        source = record['source']
        if source not in CONTRACT:
            rejected.append('unknown_source')
            continue
        target, wire_scale = CONTRACT[source]
        if target in seen:
            rejected.append('duplicate_source')
            continue
        # First occurrence owns the source, even if it is empty or invalid.
        seen.add(target)
        if 'value' not in record:
            rejected.append('invalid_record')
            continue
        value = record['value']
        if value is None:
            rejected.append('empty_value')
            continue
        if type(value) not in (int, float) or not 0 <= value <= wire_scale or not math.isfinite(value):
            rejected.append('invalid_value')
            continue
        score = record.get('score')
        if score is not None:
            if (type(score) not in (int, float) or not 0 <= score <= 100 or
                    not math.isfinite(score)):
                rejected.append('inconsistent_scale')
                continue
            # Both TMDb contracts were observed in the actual cache. Never
            # infer /10 from a small value alone or substitute score for value.
            if source == 'tmdb' and value <= 10 and abs(score - value * 10) <= 1.0:
                if value != 0 and abs(score - value) <= 1.0:
                    rejected.append('inconsistent_scale')  # ambiguous low score
                    continue
                wire_scale = 10
            if abs(score - value * 100 / wire_scale) > 1.0:
                rejected.append('inconsistent_scale')
                continue
        votes = record.get('votes')
        votes = votes if type(votes) is int and votes >= 0 else None
        scale = SOURCES[target][1]
        values.append(Rating(target, value * scale / wire_scale, scale, votes))
    return ParsedRatings(tuple(values), tuple(rejected))


def read_ratings(client, item_id):
    """Worker-side bridge from CacheClient into Ratings.fetch; never call on UI."""
    payload = client.read(item_id)
    parsed = parse_cached(payload)
    # A genuinely empty cache differs from an entirely unknown/broken schema.
    if not parsed.ratings and any(code != 'empty_value' for code in parsed.rejected):
        raise RatingsError('invalid_data')
    return RatingResult(parsed.ratings, parsed.rejected, cached_at=payload.get('cachedAtUtc'))
