"""Kodi 21 adapter; imports Kodi modules only on the device.

All property writes happen on the service thread. Workers only read the cache
endpoint. Fixed diagnostic codes are the only error output.
"""
import json
from pathlib import Path
import time

from .connection import CacheClient
from .focus import FocusReader
from .jellyfin import ConnectionReader, Mapping, MappingItemMissing
from .kodi_navigation import VIEWS, Locator, destination, read_batch
from .mdblist import read_ratings
from .ratings import Ratings, RatingsError, RequestPool, REJECTION_CODES, SOURCES, slots
from .persistent_ratings import PersistentRatings, namespace
from .episode_rows import EpisodeRows, ROW_LIMIT
from .subtitle_startup import startup_player
from .addon_updates import UpdateWatcher

SKIN = 'skin.embuary.flow.probe'
ADDON = 'script.embuary.flow.helper'
MODAL_DIALOG = 'System.HasActiveModalDialog | System.HasVisibleModalDialog'
RATINGS_BLOCKED = 'Player.HasMedia | Library.IsScanningVideo'
LABELS = {'rt_critics': 'RT 影评', 'rt_audience': 'RT 观众'}


def rating_options(addon):
    """Invalid saved settings use safe defaults without restarting the worker."""
    invalid = False
    def sources(key):
        nonlocal invalid
        values = tuple(x.strip().lower() for x in addon.getSetting(key).split(',') if x.strip())
        if len(set(values)) != len(values) or set(values) - set(SOURCES):
            invalid = True
            return ()
        return values
    order, hidden = sources('order'), sources('hidden')
    try:
        # Legacy integer sliders persist values such as "8.000000".
        value = float(addon.getSetting('limit') or '8')
        if not value.is_integer() or not 1 <= value <= 8:
            raise ValueError()
        limit = int(value)
    except (ValueError, OverflowError):
        limit, invalid = 8, True
    return order or None, hidden, limit, invalid


def rpc(xbmc, method, params):
    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if 'error' in response:
        raise ValueError('rpc_failed')
    return response['result']


def focused_reader(xbmc, gui):
    if xbmc.getCondVisibility(MODAL_DIALOG):
        return None
    window = gui.getCurrentWindowId()
    if window in (10025, 10000, 11120, 11121):
        # Native focus identifies one control without nine Python-to-GUI
        # discovery calls. The complete audited flag vector is still checked
        # after each identity sample, including all unfocused video views.
        control = gui.Window(window).getFocusId()
        if control <= 0 or (window == 10025 and control not in VIEWS):
            return None
        containers = (control,)
        audited = VIEWS if window == 10025 else containers
    else:
        return None
    return FocusReader(gui.getCurrentWindowId,
                       lambda keys: {k: xbmc.getInfoLabel(k) for k in keys},
                       lambda keys: {k: xbmc.getCondVisibility(k) for k in keys},
                       {window: containers},
                       focus_unchanged=lambda checks, flags: xbmc.getCondVisibility(
                           ' + '.join(('' if candidate == control else '!') +
                                      'Control.HasFocus(%d)' % candidate
                                      for candidate in audited))).read()


def episode_neighbors(xbmc):
    """One bounded GUI query, excluding parent rows and invalid identities."""
    keys = [('Container(59).ListItemNoWrap(%d).DBTYPE' % offset,
             'Container(59).ListItemNoWrap(%d).DBID' % offset)
            for offset in range(-5, 6)]
    count_key = 'Container(59).NumItems'
    labels = rpc(xbmc, 'XBMC.GetInfoLabels', {
        'labels': [key for pair in keys for key in pair] + [count_key]})
    if not isinstance(labels, dict):
        raise ValueError('invalid_gui_labels')
    count = labels.get(count_key, '')
    if (isinstance(count, str) and count.isascii() and count.isdecimal()
            and 0 < len(count) <= 2 and 0 < int(count) <= ROW_LIMIT):
        # A short list fits entirely in the existing bounded display cache.
        # Relative +/-5 samples otherwise evict its first rows at the bottom,
        # creating a visible gap until cached values are republished on return.
        keys = [('Container(59).ListItemAbsolute(%d).DBTYPE' % index,
                 'Container(59).ListItemAbsolute(%d).DBID' % index)
                for index in range(int(count))]
        labels = rpc(xbmc, 'XBMC.GetInfoLabels', {
            'labels': [key for pair in keys for key in pair]})
        if not isinstance(labels, dict):
            raise ValueError('invalid_gui_labels')
    return tuple(int(labels[b]) for a, b in keys
                 if labels.get(a) == 'episode' and isinstance(labels.get(b), str) and
                 len(labels[b]) <= 10 and labels[b].isascii() and labels[b].isdecimal() and
                 0 < int(labels[b]) <= 2147483647)


def episode_dates(xbmc, items):
    """Bounded, read-only batch of current episode dates, keyed by RPC id."""
    requests = [{'jsonrpc': '2.0', 'id': dbid, 'method': 'VideoLibrary.GetEpisodeDetails',
                 'params': {'episodeid': dbid, 'properties': ['firstaired']}}
                for dbid in items[:11]]
    if not requests:
        return {}
    responses = json.loads(xbmc.executeJSONRPC(json.dumps(requests)))
    if not isinstance(responses, list):
        raise ValueError('invalid_episode_dates')
    result = {}
    for response in responses:
        if not isinstance(response, dict):
            continue
        response_result = response.get('result')
        if not isinstance(response_result, dict):
            continue
        details = response_result.get('episodedetails')
        if not isinstance(details, dict):
            continue
        dbid = response.get('id')
        if (type(dbid) is int and dbid in items and
                type(details.get('episodeid')) is int and details.get('episodeid') == dbid):
            result[dbid] = details.get('firstaired')
    return result


def episode_context_current(xbmc, xbmcgui, folder):
    """A row belongs to its list scope, not to the transient focused DBID."""
    try:
        return (bool(folder) and xbmcgui.getCurrentWindowId() == 10025 and
                xbmc.getCondVisibility('Control.HasFocus(59)') and
                xbmc.getInfoLabel('Container.FolderPath') == folder and
                xbmcgui.getCurrentWindowId() == 10025 and
                xbmc.getInfoLabel('Container.FolderPath') == folder)
    except Exception:
        return False


def clear(home, state='idle', count=8):
    home.clearProperty('Flow.Ratings.Identity')
    home.clearProperty('Flow.Ratings.DBTYPE')
    home.clearProperty('Flow.Ratings.DBID')
    home.setProperty('Flow.Ratings.State', state)
    home.clearProperty('Flow.Ratings.Rejected')
    for i in range(1, count + 1):
        home.clearProperty('Flow.Rating.%d' % i)
        home.clearProperty('Flow.Rating.%d.Source' % i)
        home.clearProperty('Flow.Rating.%d.Platform' % i)
        home.clearProperty('Flow.Rating.%d.Value' % i)


class Presentation:
    def __init__(self, home):
        self.home, self.previous = home, None

    def show(self, state='idle', identity='', values=(), rejected=(), sources=()):
        diagnostics = ', '.join('%s:%d' % (code, rejected.count(code))
                                for code in sorted(set(rejected) & REJECTION_CODES))
        snapshot = (state, identity, tuple(values), diagnostics, tuple(sources))
        if snapshot == self.previous:
            return
        # Startup removes all potentially stale slots. Later transitions
        # clear only slots this presentation actually published; identity is
        # still removed first, and shrinking/empty results retire old slots.
        clear(self.home, state, len(self.previous[2]) if self.previous is not None else 8)
        for i, value in enumerate(values, 1):
            self.home.setProperty('Flow.Rating.%d' % i, value)
            platform, separator, number = value.rpartition('  ')
            if separator:
                self.home.setProperty('Flow.Rating.%d.Platform' % i, platform)
                self.home.setProperty('Flow.Rating.%d.Value' % i, number)
            if i <= len(sources) and sources[i - 1] in SOURCES:
                self.home.setProperty('Flow.Rating.%d.Source' % i, sources[i - 1])
        if identity:
            media_type, dbid = identity.split(':', 1)
            self.home.setProperty('Flow.Ratings.DBTYPE', media_type)
            self.home.setProperty('Flow.Ratings.DBID', dbid)
        self.home.setProperty('Flow.Ratings.Identity', identity)
        self.home.setProperty('Flow.Ratings.Rejected', diagnostics)
        self.previous = snapshot


def run_service():
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs

    class Monitor(xbmc.Monitor):
        dirty = False
        settings_dirty = False

        def onNotification(self, sender, method, data):
            if method.startswith(('VideoLibrary.', 'System.')):
                self.dirty = True

        def onSettingsChanged(self):
            self.dirty = True
            self.settings_dirty = True

    monitor, home = Monitor(), xbmcgui.Window(10000)
    updates = UpdateWatcher(
        xbmcvfs.translatePath('special://database/Addons33.db'),
        Path(xbmcvfs.translatePath('special://profile/')) / 'addon_data' / ADDON / 'update-reminders.json',
        lambda directory: xbmcvfs.listdir(directory),
        lambda message: xbmcgui.Dialog().notification('Flow 插件更新', message, time=10000),
        lambda message: xbmc.log(message, xbmc.LOGWARNING))
    subtitles = startup_player(xbmc, SKIN)
    presentation = Presentation(home)
    episode_rows = EpisodeRows(home, xbmcgui.Window(10025))
    addon = xbmcaddon.Addon(ADDON)
    engine, identity, last_focus = None, None, None
    checked_profile, next_identity_check = None, 0.0
    item_error, retry_at, published = None, 0.0, None
    mapped = False
    persistent, cache_profile = None, None
    cache_recovered = False
    options = rating_options(addon)
    requests = RequestPool()
    config_state = None
    connection_reader = ConnectionReader()
    next_metrics_publish = 0.0
    row_sample, row_items, next_row_sample = None, (), 0.0
    home.clearProperty('Flow.Ratings.Performance')
    presentation.show()
    try:
        while not monitor.abortRequested():
            subtitles.tick()
            try:
                if getattr(monitor, 'settings_dirty', False):
                    options = rating_options(addon)
                    monitor.settings_dirty = False
                order, hidden, limit, invalid = options
                current_config_state = 'invalid_settings' if invalid else 'valid'
                if current_config_state != config_state:
                    home.setProperty('Flow.Ratings.ConfigState', current_config_state)
                    config_state = current_config_state
                if xbmc.getSkinDir() != SKIN or xbmc.getCondVisibility(RATINGS_BLOCKED):
                    if engine:
                        engine.close()
                    engine, identity, last_focus = None, None, None
                    item_error, published = None, None
                    presentation.show()
                    episode_rows.reset()
                    monitor.waitForAbort(0.2)
                    continue
                profile = xbmcvfs.translatePath('special://profile/')
                update_state = Path(profile) / 'addon_data' / ADDON / 'update-reminders.json'
                if updates.state != update_state:
                    updates.state = update_state
                    updates.started, updates.next_check = None, 60.0
                updates.database = Path(xbmcvfs.translatePath('special://database/Addons33.db'))
                updates.tick(time.monotonic(), not xbmc.getCondVisibility(MODAL_DIALOG))
                focus = focused_reader(xbmc, xbmcgui)
                now = time.monotonic()
                config = Path(profile) / 'addon_data/plugin.video.jellyfin/data.json'
                if (engine is None or monitor.dirty or profile != checked_profile or
                        focus != last_focus or now >= next_identity_check):
                    try:
                        jellyfin = xbmcaddon.Addon('plugin.video.jellyfin')
                    except RuntimeError:
                        raise RatingsError('not_configured') from None
                    if jellyfin.getAddonInfo('version').split('+')[0] != '2.2.0':
                        raise RatingsError('not_configured')
                    mapping = Mapping(xbmcvfs.translatePath('special://database/jellyfin.db'))
                    connection = connection_reader(config)
                    current_identity = connection.identity(profile, mapping.generation())
                    recover_cache = (persistent is not None and
                                     getattr(persistent, 'disabled', False) is True and
                                     not cache_recovered)
                    if current_identity != identity or monitor.dirty or recover_cache:
                        episode_rows.reset()
                        if engine:
                            engine.close()
                        client = CacheClient(connection.url, connection.token)
                        if persistent is None or cache_profile != profile or recover_cache:
                            if persistent:
                                persistent.close()
                            # Preserve the failed database for diagnosis. A
                            # separate schema-versioned file can be populated
                            # by accepted API results without deleting files.
                            cache_recovered = recover_cache and cache_profile == profile
                            filename = 'ratings-v1-recovered.sqlite' if cache_recovered else 'ratings-v1.sqlite'
                            persistent = PersistentRatings(Path(profile) / 'addon_data' / ADDON / filename)
                            cache_profile = profile
                        stable = connection.identity(profile, 'persistent-v1')
                        engine = Ratings(lambda unused, item, client=client: read_ratings(client, item.split(':', 1)[1]),
                                         persistent=persistent, cache_namespace=namespace(stable), executor=requests)
                        engine.switch_identity(current_identity)
                        identity, last_focus = current_identity, None
                        # Preserve a stationary item's diagnostic until resolution succeeds.
                        published = None
                    checked_profile, next_identity_check = profile, now + 1.0
                    monitor.dirty = False
                if focus != last_focus:
                    # Publish the validated new snapshot below. An eager idle
                    # write here needlessly blanks even a warm memory hit.
                    # Torn/absent focus still clears in the rejection branch.
                    engine.cancel()
                    last_focus = focus
                    item_error, retry_at, published = None, 0.0, None
                    mapped = False
                if focus and not mapped and now >= retry_at:
                    try:
                        engine.focus(focus.media_type + ':' + mapping.resolve(focus.media_type, focus.dbid))
                        item_error = None
                        mapped = True
                    except MappingItemMissing:
                        engine.cancel()
                        item_error, retry_at = 'mapping_missing', now + 1.5
                if item_error:
                    presentation.show(item_error)
                    if not (focus and focus.window == 10025 and focus.container == 59 and
                            focus.media_type == 'episode'):
                        episode_rows.reset()
                        monitor.waitForAbort(0.1)
                        continue
                if home.getProperty('Flow.Ratings.Refresh'):
                    home.clearProperty('Flow.Ratings.Refresh')
                    episode_rows.reset()
                    engine.refresh()
                engine.pump()
                values, rejected = slots(engine.values, order, hidden, limit)
                snapshot = (item_error or engine.error or engine.state, focus, tuple(
                    (v['source'], v['label'], v['value']) for v in values),
                    getattr(engine, 'rejected', ()) + tuple(rejected))
                # Unchanged snapshots perform no presentation writes. Recheck
                # focus only before an actual publication; scoped row writes
                # retain their independent context and connection checks.
                needs_publish = snapshot != published
                # Mapping and pumping can race a profile/config/library change.
                # Recheck the full identity before publishing, not only DBID.
                publish = (focus is not None and not monitor.dirty and
                           not monitor.abortRequested() and xbmc.getSkinDir() == SKIN and
                           not xbmc.getCondVisibility(RATINGS_BLOCKED) and
                           xbmcvfs.translatePath('special://profile/') == profile and
                           (not needs_publish or
                            connection_reader(config).identity(profile, mapping.generation()) == identity) and
                           (not needs_publish or focus == focused_reader(xbmc, xbmcgui)))
                if publish:
                    presentation.show(item_error or engine.error or engine.state,
                                      '%s:%d' % (focus.media_type, focus.dbid),
                                      tuple(LABELS.get(v['source'], v['label']) + '  ' + v['value'] for v in values),
                                      getattr(engine, 'rejected', ()) + tuple(rejected),
                                      tuple(v['source'] for v in values))
                    published = snapshot
                    engine.mark_published()
                    if (focus.window == 10025 and focus.container == 59 and
                            focus.media_type == 'episode'):
                        folder = xbmc.getInfoLabel('Container.FolderPath')
                        sample = (identity, focus, folder)
                        if sample != row_sample or now >= next_row_sample:
                            try:
                                row_items = episode_neighbors(xbmc)
                            except (ValueError, KeyError, TypeError):
                                # A torn neighbor read does not invalidate
                                # already identity-bound rows in this scope.
                                row_items = (episode_rows.items if
                                             episode_rows.scope == (identity, folder) else ())
                            row_sample, next_row_sample = sample, now + .5
                        def context_allowed():
                            return (episode_context_current(xbmc, xbmcgui, folder) and
                                    not monitor.dirty and not monitor.abortRequested() and
                                    xbmc.getSkinDir() == SKIN and
                                    not xbmc.getCondVisibility(RATINGS_BLOCKED) and
                                    xbmcvfs.translatePath('special://profile/') == profile)
                        def allowed():
                            return (context_allowed() and
                                    connection_reader(config).identity(profile, mapping.generation()) == identity)
                        episode_rows.update((identity, folder),
                                            row_items, engine, mapping, options, allowed, context_allowed,
                                            None if folder.startswith('videodb://') else
                                            lambda items: episode_dates(xbmc, items))
                    else:
                        if episode_rows.scope is not None:
                            episode_rows.reset()
                    if now >= next_metrics_publish:
                        latency = engine.diagnostics()['latency_ms']
                        if any(value.get('count', 0) for value in latency.values()):
                            home.setProperty('Flow.Ratings.Performance', json.dumps(latency, sort_keys=True))
                            next_metrics_publish = now + 5.0
                else:
                    # FocusReader intentionally rejects torn reads. That
                    # clears focused presentation, but must not clear every
                    # row/date when the same validated episode list remains.
                    scope = episode_rows.scope
                    retain_rows = (scope is not None and scope[0] == identity and
                                   not monitor.dirty and not monitor.abortRequested() and
                                   xbmc.getSkinDir() == SKIN and
                                   not xbmc.getCondVisibility(RATINGS_BLOCKED) and
                                   xbmcvfs.translatePath('special://profile/') == profile and
                                   episode_context_current(xbmc, xbmcgui, scope[1]) and
                                   connection_reader(config).identity(profile, mapping.generation()) == identity)
                    if not retain_rows:
                        episode_rows.reset()
                    presentation.show()
                    engine.cancel()
                    last_focus = None
                    published = None
            except Exception as exc:
                episode_rows.reset()
                presentation.show(exc.code if isinstance(exc, RatingsError) else 'invalid_data')
                if engine:
                    engine.close()
                engine, identity, last_focus = None, None, None
                item_error, published = None, None
                monitor.waitForAbort(1.5)
            # Ready results need no 10 Hz pumping. Keep cold/error paths
            # responsive while reducing GUI lock crossings for warm browsing.
            monitor.waitForAbort(0.2 if engine is not None and engine.state == 'ready' else 0.1)
    finally:
        episode_rows.reset()
        home.clearProperty('Flow.Ratings.Performance')
        if persistent:
            persistent.close()
        presentation.show()
        if engine:
            engine.close()
        requests.shutdown(wait=False)


def navigate(expected):
    import xbmc
    import xbmcgui
    import xbmcvfs

    if xbmc.getSkinDir() != SKIN or xbmc.getCondVisibility('Player.HasMedia'):
        return
    media_type, dbid, source_container = expected
    if media_type not in ('movie', 'episode') or type(dbid) is not int or dbid <= 0:
        return
    launch_window = xbmcgui.getCurrentWindowId()
    home = xbmcgui.Window(10000)
    pending = '%s:%d:%d' % expected
    if home.getProperty('Flow.Navigation.Pending') != pending:
        return  # cancelled before the Python entrypoint started
    origin = home.getProperty('Flow.Navigation.Origin')
    launched_from_home = (launch_window == 10000 or
                          (launch_window == 10025 and origin.isdecimal() and
                           origin == str(source_container)))
    source = focused_reader(xbmc, xbmcgui)
    if xbmcgui.getCurrentWindowId() != 10025 and (
            source is None or source.window != 10000 or
            (source.media_type, source.dbid, source.container) != expected):
        return
    home.clearProperty('Flow.Navigation.Pending')  # one-shot claim
    # A new invocation cancels an older scan before it can write focus.
    serial = str(time.monotonic_ns())
    home.setProperty('Flow.Navigation.Request', serial)
    home.setProperty('Flow.Navigation.State', 'loading')
    monitor = xbmc.Monitor()
    profile = xbmcvfs.translatePath('special://profile/')
    try:
        initial_target = None
        if xbmcgui.getCurrentWindowId() == 10025:
            initial_target = (xbmcgui.Window(10025).getFocusId(),
                              xbmc.getInfoLabel('ListItem.DBTYPE'),
                              xbmc.getInfoLabel('ListItem.DBID'),
                              xbmc.getInfoLabel('Container.FolderPath'))
        initial_fallback = None
        if (media_type == 'episode' and xbmcgui.getCurrentWindowId() == 10025 and
                xbmc.getInfoLabel('Container.FolderPath').startswith('videodb://tvshows/titles/')):
            initial_fallback = (xbmcgui.Window(10025).getFocusId(),
                                xbmc.getInfoLabel('ListItem.DBTYPE'),
                                xbmc.getInfoLabel('ListItem.DBID'),
                                xbmc.getInfoLabel('Container.FolderPath'))
        path = destination(media_type, dbid, lambda m, p: rpc(xbmc, m, p))
        if (home.getProperty('Flow.Navigation.Request') != serial or
                monitor.abortRequested() or xbmc.getSkinDir() != SKIN or
                xbmc.getCondVisibility('Player.HasMedia') or
                xbmcvfs.translatePath('special://profile/') != profile):
            return
        if (initial_target is not None and initial_target[3].split('?')[0].rstrip('/') == path.rstrip('/')
                and (xbmcgui.getCurrentWindowId() != 10025 or initial_target != (
                    xbmcgui.Window(10025).getFocusId(), xbmc.getInfoLabel('ListItem.DBTYPE'),
                    xbmc.getInfoLabel('ListItem.DBID'), xbmc.getInfoLabel('Container.FolderPath')))):
            return
        if initial_fallback is not None:
            current_fallback = (xbmcgui.Window(10025).getFocusId(),
                                xbmc.getInfoLabel('ListItem.DBTYPE'),
                                xbmc.getInfoLabel('ListItem.DBID'),
                                xbmc.getInfoLabel('Container.FolderPath'))
            # During the DBID lookup Kodi may finish its own transition from
            # titles into this show's seasons. A focus change in the same
            # directory is still user movement and must cancel the request.
            owned = {path.rstrip('/'), path.rstrip('/').rsplit('/', 1)[0]}
            transitioned = (current_fallback[3] != initial_fallback[3] and
                            current_fallback[3].split('?')[0].rstrip('/') in owned and
                            current_fallback[0] in VIEWS)
            if (xbmcgui.getCurrentWindowId() != 10025 or
                    (current_fallback != initial_fallback and not transitioned)):
                return
        locator = Locator(media_type, dbid)
        # Activation belongs to the skin click action. A delayed helper must
        # never open/reopen a page after Back or after a startup failure.
        entered = False
        # Kodi can pass through the show's season directory after opening
        # titles (including its cached/auto-selected show). Both are owned
        # fallbacks only for this exact DBID-resolved show, not arbitrary seasons.
        fallback_paths = {'videodb://tvshows/titles'}
        if media_type == 'episode':
            fallback_paths.add(path.rstrip('/').rsplit('/', 1)[0])
        redirected_fallbacks = set()
        while not locator.done and not monitor.abortRequested():
            if (home.getProperty('Flow.Navigation.Request') != serial or
                    xbmc.getSkinDir() != SKIN or xbmc.getCondVisibility('Player.HasMedia') or
                    xbmc.getCondVisibility(MODAL_DIALOG) or
                    xbmcvfs.translatePath('special://profile/') != profile or
                    time.monotonic() >= locator.deadline):
                break
            window = xbmcgui.getCurrentWindowId()
            if window != 10025:
                if entered or window != 10000:
                    break
                if source != focused_reader(xbmc, xbmcgui):
                    break
                monitor.waitForAbort(0.02)
                continue
            entered = True
            context = (xbmc.getInfoLabel('Container.FolderPath'),
                       xbmc.getInfoLabel('Container.SortMethod'),
                       str(xbmc.getCondVisibility('Container.SortDirection(ascending)')))
            if context[0].split('?')[0].rstrip('/') != path.rstrip('/'):
                if locator.snapshot is not None:
                    break
                normalized_folder = context[0].split('?')[0].rstrip('/')
                # A Home launch may reopen Kodi's last selected show root
                # instead of the requested titles root. Resolve that single
                # numeric show directory from the captured episode DBID.
                cached_home_show = (
                    launched_from_home and media_type == 'episode' and
                    normalized_folder.startswith('videodb://tvshows/titles/') and
                    normalized_folder[len('videodb://tvshows/titles/'):].isdecimal())
                if (context[0].startswith('videodb://tvshows/titles/') and
                        context[0].split('?')[0].rstrip('/') != 'videodb://tvshows/titles' and
                        normalized_folder not in fallback_paths and not cached_home_show and
                        not any(xbmc.getCondVisibility('Container(%d).IsUpdating' % cid) for cid in VIEWS)):
                    break  # An unrelated, stable season is not this transaction.
                # The skin keeps a safe show-list fallback when its episode
                # labels lack parent IDs. Resolve from the DBID, never title.
                # Only replace each untouched fallback once, at most two
                # paths, while this request owns the navigation transaction.
                if (media_type == 'episode' and
                        (normalized_folder in fallback_paths or cached_home_show) and
                        normalized_folder not in redirected_fallbacks):
                    fallback_container = xbmcgui.Window(window).getFocusId()
                    if (fallback_container not in VIEWS or
                            xbmc.getCondVisibility('Container(%d).IsUpdating' % fallback_container)):
                        monitor.waitForAbort(0.02)
                        continue
                    fallback_focus = (xbmc.getInfoLabel('ListItem.DBTYPE'),
                                      xbmc.getInfoLabel('ListItem.DBID'))
                    resolved = destination(media_type, dbid, lambda m, p: rpc(xbmc, m, p))
                    if (resolved != path or home.getProperty('Flow.Navigation.Request') != serial or
                            xbmcgui.getCurrentWindowId() != window or
                            xbmcgui.Window(window).getFocusId() != fallback_container or
                            xbmc.getInfoLabel('Container.FolderPath') != context[0] or
                            xbmc.getInfoLabel('Container.SortMethod') != context[1] or
                            str(xbmc.getCondVisibility('Container.SortDirection(ascending)')) != context[2] or
                            (xbmc.getInfoLabel('ListItem.DBTYPE'), xbmc.getInfoLabel('ListItem.DBID')) != fallback_focus or
                            xbmc.getCondVisibility('Container(%d).IsUpdating' % fallback_container) or
                            monitor.abortRequested() or xbmc.getSkinDir() != SKIN or
                            xbmc.getCondVisibility('Player.HasMedia') or
                            xbmc.getCondVisibility(MODAL_DIALOG) or
                            xbmcvfs.translatePath('special://profile/') != profile or
                            time.monotonic() >= locator.deadline):
                        break
                    redirected_fallbacks.add(normalized_folder)
                    xbmc.executebuiltin('Container.Update(%s,replace)' % resolved)
                monitor.waitForAbort(0.02)
                continue
            container = xbmcgui.Window(window).getFocusId()
            if container not in VIEWS:
                if locator.snapshot is not None:
                    break
                monitor.waitForAbort(0.02)
                continue
            if xbmc.getCondVisibility('Container(%d).IsUpdating' % container):
                monitor.waitForAbort(0.02)
                continue
            focused = (xbmc.getInfoLabel('ListItem.DBTYPE'), xbmc.getInfoLabel('ListItem.DBID'))
            count = int(xbmc.getInfoLabel('Container(%d).NumAllItems' % container) or '0')
            if count <= 0 and locator.snapshot is None:
                monitor.waitForAbort(0.02)
                continue

            def read_identity(cid, position):
                prefix = 'Container(%d).ListItemAbsolute(%d).' % (cid, position)
                dbid = xbmc.getInfoLabel(prefix + 'DBID')
                return xbmc.getInfoLabel(prefix + 'DBTYPE'), int(dbid) if dbid.isdecimal() else 0

            identities = read_batch(container, locator.cursor, count,
                                    lambda m, p: rpc(xbmc, m, p))
            position = locator.step(container, count, context, focused,
                                    lambda cid, pos: identities[pos])
            if position is not None:
                if (xbmcgui.getCurrentWindowId() == window and
                        xbmcgui.Window(window).getFocusId() == container and
                        home.getProperty('Flow.Navigation.Request') == serial and
                        xbmc.getInfoLabel('Container.FolderPath') == context[0] and
                        xbmc.getInfoLabel('Container.SortMethod') == context[1] and
                        str(xbmc.getCondVisibility('Container.SortDirection(ascending)')) == context[2] and
                        not xbmc.getCondVisibility('Player.HasMedia') and
                        not xbmc.getCondVisibility(MODAL_DIALOG) and
                        not xbmc.getCondVisibility('Container(%d).IsUpdating' % container) and
                        (xbmc.getInfoLabel('ListItem.DBTYPE'), xbmc.getInfoLabel('ListItem.DBID')) == focused and
                        int(xbmc.getInfoLabel('Container(%d).NumAllItems' % container) or '0') == count and
                        read_identity(container, position) == (media_type, dbid) and
                        not monitor.abortRequested() and xbmc.getSkinDir() == SKIN and
                        xbmcvfs.translatePath('special://profile/') == profile and
                        time.monotonic() < locator.deadline and
                        home.getProperty('Flow.Navigation.Request') == serial):
                    xbmc.executebuiltin('SetFocus(%d,%d,absolute)' % (container, position))
                    home.setProperty('Flow.Navigation.State', 'focus_requested')
                    # SetFocus is queued by Kodi; report success only after a
                    # live identity read. Never retry focus after user input.
                    monitor.waitForAbort(0.05)
                    if (home.getProperty('Flow.Navigation.Request') == serial and
                            xbmcgui.getCurrentWindowId() == window and
                            xbmcgui.Window(window).getFocusId() == container and
                            xbmc.getInfoLabel('Container.FolderPath') == context[0] and
                            xbmc.getInfoLabel('Container.SortMethod') == context[1] and
                            str(xbmc.getCondVisibility('Container.SortDirection(ascending)')) == context[2] and
                            int(xbmc.getInfoLabel('Container(%d).NumAllItems' % container) or '0') == count and
                            not xbmc.getCondVisibility('Container(%d).IsUpdating' % container) and
                            not xbmc.getCondVisibility('Player.HasMedia') and
                            not xbmc.getCondVisibility(MODAL_DIALOG) and
                            not monitor.abortRequested() and xbmc.getSkinDir() == SKIN and
                            xbmcvfs.translatePath('special://profile/') == profile and
                            time.monotonic() < locator.deadline and
                            xbmc.getInfoLabel('ListItem.DBTYPE') == media_type and
                            xbmc.getInfoLabel('ListItem.DBID') == str(dbid)):
                        home.setProperty('Flow.Navigation.State', 'located')
                break
            monitor.waitForAbort(0.01)
    except Exception:
        # Skin already opened safe browsing. No asynchronous fallback action
        # may reopen a window after cancellation.
        if (home.getProperty('Flow.Navigation.Request') == serial and
                xbmc.getSkinDir() == SKIN and not monitor.abortRequested() and
                not xbmc.getCondVisibility('Player.HasMedia') and
                not xbmc.getCondVisibility(MODAL_DIALOG) and
                xbmcvfs.translatePath('special://profile/') == profile):
            home.setProperty('Flow.Navigation.State', 'not_located')
    finally:
        if home.getProperty('Flow.Navigation.Request') == serial:
            home.clearProperty('Flow.Navigation.Request')
            if home.getProperty('Flow.Navigation.State') == 'loading':
                home.setProperty('Flow.Navigation.State', 'not_located')
