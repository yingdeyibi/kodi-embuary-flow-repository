"""Read-only MDBList cache transport, independent of plugin rating normalization.

Endpoint verified against upstream CachedRatingsController.cs on 2026-10-03;
user-installed plugin version pending. Recorded field/scale adapter: mdblist.py.
No credentials are loaded implicitly or emitted in diagnostics. Redirects and
environment proxies are disabled so authentication is sent only to this server.
"""
import json
from http.client import HTTPException
import socket
import ssl
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener
import uuid

from .ratings import RatingsError


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class CacheClient:
    def __init__(self, server_url, token, timeout=2.0, opener=None):
        if not 1.5 <= timeout <= 3:
            raise ValueError('API timeout must be 1.5–3 seconds')
        if not isinstance(server_url, str) or not isinstance(token, str) or not token:
            raise RatingsError('not_configured')
        parsed = urlsplit(server_url)
        if (parsed.scheme not in ('http', 'https') or not parsed.hostname or
                parsed.username is not None or parsed.password is not None or
                parsed.query or parsed.fragment or any(ord(c) < 33 for c in server_url) or
                any(ord(c) < 32 for c in token)):
            raise RatingsError('not_configured')
        self._base, self._token = server_url.rstrip('/'), token
        self.timeout = timeout
        self._opener = opener or build_opener(ProxyHandler({}), NoRedirect())

    def read(self, item_id):
        try:
            item = uuid.UUID(item_id)
            if not item.int:
                raise ValueError()
        except (ValueError, AttributeError, TypeError):
            raise RatingsError('mapping_missing') from None
        auth = ('MediaBrowser Client=Embuary%20Flow, Device=Kodi, '
                'DeviceId=flow-helper, Version=0.1, Token=' + quote(self._token, safe=''))
        request = Request(self._base + '/Plugins/MdbListRatings/CachedByItemId?itemId=' + item.hex,
                          headers={'Authorization': auth, 'Accept': 'application/json'}, method='GET')
        try:
            with self._opener.open(request, timeout=self.timeout) as response:
                if response.status != 200:
                    raise RatingsError('endpoint_unavailable')
                data = response.read(1024 * 1024 + 1)
                if len(data) > 1024 * 1024:
                    raise RatingsError('invalid_data')
            payload = json.loads(data)
        except HTTPError as exc:
            code = 'auth_failed' if exc.code in (401, 403) else 'endpoint_unavailable'
            # Python 3.9 HTTPError has no initialized stream wrapper when fp is
            # None; closing that object raises KeyError instead of our safe code.
            if exc.fp is not None:
                exc.close()
            raise RatingsError(code) from None
        except (socket.timeout, TimeoutError):
            raise RatingsError('timeout') from None
        except URLError as exc:
            code = 'timeout' if isinstance(exc.reason, (socket.timeout, TimeoutError)) else 'connection_failed'
            raise RatingsError(code) from None
        except (ssl.SSLError, HTTPException):
            raise RatingsError('connection_failed') from None
        except (ValueError, UnicodeError):
            raise RatingsError('invalid_data') from None
        except OSError:
            raise RatingsError('connection_failed') from None
        if not isinstance(payload, dict) or type(payload.get('hasCache')) is not bool:
            raise RatingsError('invalid_data')
        if not payload['hasCache']:
            raise RatingsError('no_cache')
        if not isinstance(payload.get('ratings'), list):
            raise RatingsError('invalid_data')
        return payload
