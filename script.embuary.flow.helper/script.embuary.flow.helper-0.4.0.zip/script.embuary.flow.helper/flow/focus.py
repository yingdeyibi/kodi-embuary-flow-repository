"""Read-only focus sampling using explicitly audited window/container IDs.

Callbacks can wrap Kodi getInfoLabel/getCondVisibility or the corresponding
JSON-RPC methods. A sample is advisory: the navigation dispatcher must recheck
it before applying actions. No container enumeration or title matching.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class MediaFocus:
    window: int
    container: int
    media_type: str
    dbid: int


def _dbid(value):
    if not isinstance(value, str) or not value.isascii() or not value.isdecimal():
        return None
    result = int(value) if len(value) <= 10 else 0
    return result if 0 < result <= 2147483647 else None


class FocusReader:
    def __init__(self, window_id, labels, booleans, containers_by_window, *, focus_unchanged=None):
        self.window_id, self.labels, self.booleans = window_id, labels, booleans
        self.focus_unchanged = focus_unchanged
        self.containers = {}
        for window, containers in containers_by_window.items():
            values = tuple(containers)
            if (type(window) is not int or window <= 0 or not values or
                    len(set(values)) != len(values) or
                    any(type(value) is not int or value <= 0 for value in values)):
                raise ValueError('Explicit audited window/container IDs required')
            self.containers[window] = values

    def _sample(self):
        window = self.window_id()
        if type(window) is not int:
            return None
        containers = self.containers.get(window, ())
        if not containers:
            return None
        checks = tuple('Control.HasFocus(%d)' % item for item in containers)
        flags = self.booleans(checks)
        active = [item for item, check in zip(containers, checks) if flags.get(check) is True]
        if len(active) != 1:
            return None
        container = active[0]
        prefix = 'Container(%d).ListItem.' % container
        keys = (prefix + 'DBID', prefix + 'DBTYPE', 'ListItem.DBID', 'ListItem.DBTYPE')
        labels = self.labels(keys)
        dbid, media_type = _dbid(labels.get(keys[0])), labels.get(keys[1])
        if (dbid is None or media_type not in ('movie', 'episode', 'season', 'tvshow') or
                dbid != _dbid(labels.get(keys[2])) or media_type != labels.get(keys[3])):
            return None
        # Reject a focus/window change that occurred while querying labels.
        if self.window_id() != window:
            return None
        # Kodi can verify the same complete flag vector in one boolean call.
        # Other adapters retain the original dictionary comparison.
        unchanged = (self.focus_unchanged(checks, flags) if self.focus_unchanged is not None
                     else self.booleans(checks) == flags)
        if not unchanged:
            return None
        return MediaFocus(window, container, media_type, dbid)

    def read(self):
        try:
            first = self._sample()
            return first if first is not None and first == self._sample() else None
        except Exception:
            # Failed transport or torn reads clear presentation, never reuse it.
            return None
