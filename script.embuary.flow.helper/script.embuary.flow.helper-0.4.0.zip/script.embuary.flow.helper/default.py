import sys
import xbmcaddon
import xbmcgui
from flow.kodi_runtime import navigate
from flow.ratings import REJECTION_CODES

if __name__ == '__main__':
    action = sys.argv[1] if len(sys.argv) > 1 else 'settings'
    if action == 'navigate':
        if len(sys.argv) == 5 and sys.argv[3].isdecimal() and sys.argv[4].isdecimal():
            navigate((sys.argv[2], int(sys.argv[3]), int(sys.argv[4])))
    elif action == 'refresh':
        xbmcgui.Window(10000).setProperty('Flow.Ratings.Refresh', '1')
    elif action == 'addon_updates':
        import xbmc
        import xbmcvfs
        from flow.addon_updates import guide
        guide(xbmc, xbmcgui, xbmcvfs)
    elif action == 'addon_updates_status':
        import xbmcvfs
        from flow.addon_updates import show_status
        show_status(xbmcgui, xbmcvfs)
    elif action == 'diagnostics':
        home = xbmcgui.Window(10000)
        state = home.getProperty('Flow.Ratings.State')
        allowed = {'idle', 'loading', 'ready', 'empty', 'connection_failed', 'auth_failed',
                   'mapping_missing', 'endpoint_unavailable', 'no_cache', 'invalid_data',
                   'not_configured', 'timeout'}
        lines = [state if state in allowed else 'idle']
        if home.getProperty('Flow.Ratings.ConfigState') == 'invalid_settings':
            lines.append('评分设置无效，已使用默认值；请检查来源 ID 和显示数量。')
        for entry in home.getProperty('Flow.Ratings.Rejected').split(', '):
            code, _, count = entry.partition(':')
            if code in REJECTION_CODES and count.isascii() and count.isdecimal() and len(count) <= 7:
                lines.append(code + ': ' + count)
        xbmcgui.Dialog().ok('Flow 评分状态', '\n'.join(lines))
    else:
        xbmcaddon.Addon().openSettings()
